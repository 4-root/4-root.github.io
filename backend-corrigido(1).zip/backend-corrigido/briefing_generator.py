# -*- coding: utf-8 -*-
"""
PDF do ciclo (digest das noticias ranqueadas) - ReportLab.

Visual 4root TEMA BRANCO: capa de abertura + cartao por artigo, logo
principal (#_4root em QB One + Sora) no cabecalho de todas as paginas,
acento verde #00a833 e TODOS os artigos do ciclo (sem corte). Cada
entrada traz data/hora, fonte, titulo, resumo e o link original da
materia. Sem geracao por IA.

E o PDF baixado pelo botao "baixar pdf do ciclo" e pelos session-chips.
"""
import os
import re
import logging
from datetime import datetime, timezone

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_JUSTIFY
from reportlab.lib.colors import HexColor
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                TableStyle, PageBreak, HRFlowable)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

from config import (MESES_PT, EXPORT_DIR, BRIEFING_ORG, FONT_QB_ONE,
                    FONT_SORA, TZ_BRASILIA, now_local)

logger = logging.getLogger(__name__)


def format_date_ddmmm(dt=None):
    """Formata data como DDMMM (ex: 20OUT)."""
    if dt is None:
        dt = now_local()
    return f"{dt.day}{MESES_PT.get(dt.month, '???')}"


def format_date_ddmmaaaa(dt=None):
    """Formata data como DDMMMAAAA (ex: 20OUT2026)."""
    if dt is None:
        dt = now_local()
    return f"{dt.day}{MESES_PT.get(dt.month, '???')}{dt.year}"


def _fmt_quando(published):
    """Converte o published (ISO UTC do coletor) para o fuso de Brasilia.

    '2026-11-08T16:08:32+00:00' -> '08/11/2026 13:08 (Brasilia)'.
    Falha de parse cai no formato antigo truncado (nao estoura o PDF).
    """
    try:
        s = (published or '').strip()
        if s.endswith('Z'):
            s = s[:-1] + '+00:00'
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)   # legado sem offset
        dt = dt.astimezone(TZ_BRASILIA)
        return dt.strftime('%d/%m/%Y %H:%M') + ' (Brasilia)'
    except (ValueError, TypeError, AttributeError):
        raw = (published or '')[:16].replace('T', ' ')
        return f'{raw} UTC' if raw else ''


# ============ paleta 4root no branco ============
R_BG = HexColor('#ffffff')      # fundo branco
R_CARD = HexColor('#f7f7f7')    # cartao (cinza bem claro)
R_LINE = HexColor('#e2e2e2')    # bordas claras
R_TEXT = HexColor('#111111')    # texto escuro
R_MUTED = HexColor('#5f5f5f')   # texto apagado
R_NEON = HexColor('#00a833')    # acento verde (legivel no branco)
R_RED = HexColor('#d90429')     # erro
R_DIM = HexColor('#c9c9c9')     # linha secundaria

# ---- fontes oficiais (logo/nav = QB One; texto = Sora; meta = mono) ----
_QB_OK = _SORA_OK = _MONO_OK = False
try:
    if os.path.exists(FONT_QB_ONE):
        pdfmetrics.registerFont(TTFont('QBOne', FONT_QB_ONE))
        _QB_OK = True
    if os.path.exists(FONT_SORA):
        pdfmetrics.registerFont(TTFont('Sora4R', FONT_SORA))
        _SORA_OK = True
except Exception as exc:  # noqa: BLE001
    logger.warning(f"Fontes 4root nao registradas: {exc}")

for _mono_path in ('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf',
                   '/usr/share/fonts/truetype/liberation/LiberationMono-Regular.ttf'):
    if os.path.exists(_mono_path):
        try:
            pdfmetrics.registerFont(TTFont('Mono4R', _mono_path))
            _MONO_OK = True
            break
        except Exception:  # noqa: BLE001
            pass

F_LOGO = 'QBOne' if _QB_OK else 'Helvetica'
F_SANS = 'Sora4R' if _SORA_OK else 'Helvetica'
F_MONO = 'Mono4R' if _MONO_OK else 'Courier'


def _xml_escape(text):
    """Escapa texto para uso dentro de Paragraph (markup XML do ReportLab)."""
    if not text:
        return ''
    return (str(text).replace('&', '&amp;').replace('<', '&lt;')
            .replace('>', '&gt;'))

def _one_line(text, cap=90):
    """Colapsa quebras/espacos e limita o tamanho (mensagens de erro)."""
    return re.sub(r'\s+', ' ', str(text or '')).strip()[:cap] or 'erro'
    
def _draw_logo(c, x, y, size=28, text_color=None, accent_color=None):
    """Desenha o nav-logo '#_4root' (logo principal) e retorna a largura."""
    c.saveState()
    cx = x
    c.setFont(F_LOGO, size)
    c.setFillColor(text_color or R_TEXT)
    c.drawString(cx, y, '#_')
    cx += pdfmetrics.stringWidth('#_', F_LOGO, size)
    c.setFont('Sora4R' if _SORA_OK else F_LOGO, size)
    c.setFillColor(accent_color or R_NEON)
    c.drawString(cx, y, '4')
    cx += pdfmetrics.stringWidth('4', 'Sora4R' if _SORA_OK else F_LOGO, size)
    cx += size * 0.06
    c.setFont(F_LOGO, size)
    c.setFillColor(text_color or R_TEXT)
    c.drawString(cx, y, 'root')
    cx += pdfmetrics.stringWidth('root', F_LOGO, size)
    c.restoreState()
    return cx - x


def _paint_white_base(c, doc):
    """Fundo BRANCO + cabecalho/logo + rodape em TODAS as paginas de conteudo."""
    w, h = A4
    c.saveState()
    c.setFillColor(R_BG)
    c.rect(0, 0, w, h, stroke=0, fill=1)

    # cabecalho: nav-logo a esquerda, ciclo a direita, linha verde.
    # Tudo fica DENTRO da margem superior (acima do frame de conteudo).
    logo_size = 13
    margin = doc.leftMargin
    frame_top = h - doc.topMargin            # topo da area de conteudo
    top_y = frame_top + 14                   # baseline do logo acima do frame
    _draw_logo(c, margin, top_y, logo_size)
    c.setFont(F_MONO, 7)
    c.setFillColor(R_MUTED)
    when = getattr(doc, '_r4_when', '')
    c.drawRightString(w - margin, top_y + 1, f"BRIEFING DIARIO {when}")
    c.setStrokeColor(R_NEON)
    c.setLineWidth(0.8)
    c.line(margin, frame_top + 4, w - margin, frame_top + 4)
    c.setStrokeColor(R_DIM)
    c.setLineWidth(0.4)
    c.line(margin, frame_top + 2.5, w - margin, frame_top + 2.5)

    # rodape
    foot_y = doc.bottomMargin - 16
    c.setStrokeColor(R_DIM)
    c.line(margin, foot_y + 12, w - margin, foot_y + 12)
    c.setFont(F_MONO, 6.6)
    c.setFillColor(R_MUTED)
    c.drawString(margin, foot_y, "news.4root.com.br  [ break // learn // share ]")
    c.setFillColor(R_NEON)
    c.drawRightString(w - margin, foot_y, f"page {doc.page:02d}")
    c.restoreState()


def _paint_cover(c, doc):
    """Capa de abertura BRANCA: logo grande, 'news', motto e resumo do ciclo."""
    w, h = A4
    c.saveState()
    c.setFillColor(R_BG)
    c.rect(0, 0, w, h, stroke=0, fill=1)

    margin = doc.leftMargin
    when = getattr(doc, '_r4_when', '')

    # marca do topo (nav-logo)
    _draw_logo(c, margin, h - 3.2 * cm, 15)
    c.setFont(F_MONO, 7.5)
    c.setFillColor(R_MUTED)
    c.drawRightString(w - margin, h - 3.2 * cm + 2, "// news.4root.com.br")
    c.setStrokeColor(R_LINE)
    c.setLineWidth(0.7)
    c.line(margin, h - 3.8 * cm, w - margin, h - 3.8 * cm)

    # logo gigante centralizada (hero) — escura com '4' verde
    size = 54
    logo_w = (pdfmetrics.stringWidth('#_', F_LOGO, size)
              + pdfmetrics.stringWidth('4', 'Sora4R' if _SORA_OK else F_LOGO, size)
              + size * 0.06
              + pdfmetrics.stringWidth('root', F_LOGO, size))
    _draw_logo(c, (w - logo_w) / 2, h * 0.60, size)
    c.setFont(F_LOGO, 30)
    c.setFillColor(R_TEXT)
    c.drawCentredString(w / 2, h * 0.60 - 42, "news")

    # motto [ break // learn // share ]
    c.setFont(F_MONO, 9.5)
    my = h * 0.60 - 66
    parts = [('[ break ', R_MUTED), ('//', R_NEON), (' learn ', R_MUTED),
             ('//', R_NEON), (' share ]', R_MUTED)]
    motto_w = sum(c.stringWidth(txt, F_MONO, 9.5) for txt, _ in parts) + 8
    mx = (w - motto_w) / 2
    for txt, color in parts:
        c.setFillColor(color)
        c.drawString(mx, my, txt)
        mx += c.stringWidth(txt, F_MONO, 9.5) + (4 if txt == '//' else 0)

    # linha verde + titulo do relatorio
    c.setStrokeColor(R_NEON)
    c.setLineWidth(1)
    c.line(w * 0.30, h * 0.42, w * 0.70, h * 0.42)
    c.setFont(F_LOGO, 17)
    c.setFillColor(R_TEXT)
    c.drawCentredString(w / 2, h * 0.42 - 24, f"BRIEFING DIARIO - {BRIEFING_ORG} - {when}")
    c.setFont(F_MONO, 8.5)
    c.setFillColor(R_MUTED)
    c.drawCentredString(w / 2, h * 0.42 - 40, getattr(doc, '_r4_subtitle', ''))

    # blocos de estatistica do ciclo
    stats = getattr(doc, '_r4_stats', [])
    if stats:
        col_w = 4.4 * cm
        total_w = col_w * len(stats)
        x0 = (w - total_w) / 2
        y0 = h * 0.20
        for i, (num, label) in enumerate(stats):
            x = x0 + i * col_w
            c.setStrokeColor(R_LINE)
            c.setLineWidth(0.6)
            c.rect(x + 6, y0 - 8, col_w - 12, 52, stroke=1, fill=0)
            c.setFont(F_MONO, 15)
            c.setFillColor(R_NEON)
            c.drawCentredString(x + col_w / 2, y0 + 22, str(num))
            c.setFont(F_MONO, 6)
            c.setFillColor(R_MUTED)
            c.drawCentredString(x + col_w / 2, y0 + 2, str(label).upper())

    # rodape da capa
    c.setFont(F_MONO, 7)
    c.setFillColor(R_MUTED)
    c.drawString(margin, 1.9 * cm,
                 "Gerado automaticamente pelo 4root News System - sem geracao por IA.")
    c.drawRightString(w - margin, 1.9 * cm,
                      f"{when}  //  mais recente -> mais antiga")
    c.restoreState()


def generate_news_digest_pdf(session_data, filename=None):
    """
    Gera o PDF do ciclo a partir dos artigos ranqueados da sessao,
    da mais recente para a mais antiga, SEM corte de quantidade.
    """
    if filename is None:
        filename = f"BRIEFING - {BRIEFING_ORG} - {format_date_ddmmaaaa()}.pdf"

    all_articles = session_data.get('articles', [])
    if not all_articles:
        return None

    filepath = os.path.join(EXPORT_DIR, filename)

    # ---- estilos do digest (branco / 4root) ----
    st_entry = ParagraphStyle('R4Entry', fontName=F_SANS, fontSize=9.5,
                              leading=13.5, alignment=TA_JUSTIFY,
                              textColor=HexColor('#333333'))
    st_title = ParagraphStyle('R4Title', fontName=F_LOGO, fontSize=11.5,
                              leading=14.5, alignment=TA_LEFT,
                              textColor=R_TEXT)
    st_meta = ParagraphStyle('R4Meta', fontName=F_MONO, fontSize=7.3,
                             leading=10, alignment=TA_LEFT,
                             textColor=R_MUTED)
    st_link = ParagraphStyle('R4Link', fontName=F_MONO, fontSize=7.3,
                             leading=10, alignment=TA_LEFT,
                             textColor=R_NEON)
    st_section = ParagraphStyle('R4Section', fontName=F_LOGO, fontSize=13,
                                leading=16, alignment=TA_LEFT,
                                textColor=R_TEXT)
    st_note = ParagraphStyle('R4Note', fontName=F_MONO, fontSize=7.5,
                             leading=11, alignment=TA_LEFT,
                             textColor=R_MUTED)

    doc = SimpleDocTemplate(
        filepath, pagesize=A4,
        leftMargin=1.9 * cm, rightMargin=1.9 * cm,
        topMargin=2.7 * cm, bottomMargin=2.1 * cm,
        title=f"BRIEFING - {BRIEFING_ORG} - {format_date_ddmmm()}",
        author="4root News System",
        subject="Coleta de noticias de ciberseguranca (sem IA)",
        creator="news.4root.com.br")

    # dados usados pelos pintores de pagina
    # collected_at nasce em UTC no coletor; exibir no fuso de Brasilia
    collected = _fmt_quando(session_data.get('collected_at', ''))
    window_hours = session_data.get('window_hours', '')
    total = session_data.get('total_articles', len(all_articles))

    all_status = (session_data.get('feed_status', [])
                  + session_data.get('gnews_status', []))
    feed_errors = [f for f in all_status
                   if f.get('status') not in ('ok', 'no_results')]
    ok_sources = len([f for f in all_status
                      if f.get('status') in ('ok', 'no_results')])

    doc._r4_when = format_date_ddmmm()
    doc._r4_subtitle = (f"Coleta de noticias de ciberseguranca  //  ciclo {collected}"
                        f"  //  janela {window_hours}h  //  sem geracao por IA")
    doc._r4_stats = [
        (total, 'artigos ranqueados'),
        (ok_sources, 'fontes respondendo'),
        (len(feed_errors), 'fontes com erro'),
        (f"{window_hours}h", 'janela temporal'),
    ]

    elements = []
    elements.append(PageBreak())       # capa desenhada em _paint_cover

    # ---- cabecalho do conteudo ----
    elements.append(Paragraph("NOTICIAS RANQUEADAS DO CICLO", st_section))
    elements.append(Spacer(1, 4))
    elements.append(Paragraph(
        f"{total} artigos &bull; ciclo {collected} &bull; janela {window_hours}h "
        f"&bull; {ok_sources} fontes respondendo &bull; da mais recente para a mais antiga",
        st_note))
    elements.append(Spacer(1, 6))
    elements.append(HRFlowable(width='100%', thickness=1, color=R_NEON,
                               spaceBefore=2, spaceAfter=4))
    elements.append(HRFlowable(width='100%', thickness=0.4, color=R_DIM,
                               spaceBefore=0, spaceAfter=10))

    # ---- fontes com erro (transparencia do ciclo) ----
    if feed_errors:
        err_bits = ' &nbsp;|&nbsp; '.join(
            f"<font color='#d90429'>{_xml_escape(f.get('name', '?'))}</font>"
            f" <font color='#5f5f5f'>({_xml_escape(_one_line(f.get('message', 'erro')))})</font>"
            for f in feed_errors[:8])
        extra = (f" &nbsp;+{len(feed_errors) - 8} outras"
                 if len(feed_errors) > 8 else "")
        elements.append(Paragraph(f"fontes com erro nesta passada: {err_bits}{extra}",
                                  st_note))
        elements.append(Spacer(1, 10))

    # ---- cartao por artigo (TODOS, sem corte) ----
    doc_width = A4[0] - doc.leftMargin - doc.rightMargin

    for i, art in enumerate(all_articles, start=1):
        title = _xml_escape(art.get('title', ''))
        source = _xml_escape(art.get('source', '-'))
        link = art.get('link', '')
        published = art.get('published', '')
        when = _fmt_quando(published)
        score = art.get('relevance_score')
        art_type = art.get('type', 'rss')

        meta_bits = [f"<font color='#00a833'><b>{i:03d}</b></font>", source]
        if when:
            meta_bits.append(when)
        meta_bits.append(_xml_escape(art_type))
        if score is not None:
            meta_bits.append(f"<font color='#00a833'>score {score}</font>")
        meta_line = ' &nbsp;|&nbsp; '.join(meta_bits)

        card_content = [
            Paragraph(meta_line, st_meta),
            Spacer(1, 3),
            Paragraph(title, st_title),
        ]
        summary = _xml_escape(art.get('summary', '')[:480])
        if summary:
            card_content.append(Spacer(1, 3))
            card_content.append(Paragraph(summary, st_entry))
        if link:
            card_content.append(Spacer(1, 3))
            card_content.append(Paragraph(
                f"<link href=\"{_xml_escape(link)}\">"
                f"{_xml_escape(link)}</link>", st_link))

        card = Table([[card_content]], colWidths=[doc_width])
        card.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), R_CARD),
            ('LINEBEFORE', (0, 0), (0, -1), 1.6, R_NEON),
            ('BOX', (0, 0), (-1, -1), 0.4, R_LINE),
            ('TOPPADDING', (0, 0), (-1, -1), 7),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
            ('LEFTPADDING', (0, 0), (-1, -1), 10),
            ('RIGHTPADDING', (0, 0), (-1, -1), 8),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ]))

        elements.append(card)
        elements.append(Spacer(1, 7))

    elements.append(Spacer(1, 10))
    elements.append(HRFlowable(width='100%', thickness=0.4, color=R_DIM,
                               spaceBefore=2, spaceAfter=6))
    elements.append(Paragraph(
        f"Fim do relatorio - {len(all_articles)} de {total} artigos ranqueados "
        f"no ciclo {collected}. Cada noticia aponta para a fonte original; "
        f"nenhum texto foi gerado por IA.", st_note))

    doc.build(elements, onFirstPage=_paint_cover, onLaterPages=_paint_white_base)
    return filepath
