# -*- coding: utf-8 -*-
"""
Manutencao do 4root News - Retencao de ciclos e relatorios.

O sistema mantem apenas RETENTION_DAYS dias de historico (padrao: 6 dias).
Ao fim de cada ciclo - e na inicializacao do servidor - sao apagados:

    data/session_YYYYMMDD_HHMMSS.json   (sessoes de coleta antigas)
    data/workflow_YYYYMMDD_HHMMSS.json  (logs de workflow antigos)
    export/*.pdf                        (relatorios PDF antigos)

session_latest.json nunca e removido (e a sessao corrente).

Configure por variavel de ambiente:
    RETENTION_DAYS=6    (0 desativa a limpeza - mantem tudo)
"""
import os
import time
import logging

from config import DATA_DIR, EXPORT_DIR, RETENTION_DAYS

logger = logging.getLogger('maintenance')


def cleanup_old_artifacts(days=None):
    """Apaga sessoes, logs de workflow e PDFs com mais de N dias.

    Retorna dict com o resumo do que foi removido (para log e teste).
    """
    if days is None:
        days = RETENTION_DAYS
    summary = {'sessions': 0, 'workflows': 0, 'pdfs': 0, 'days': days}

    if days <= 0:                       # retencao desativada
        return summary

    cutoff = time.time() - days * 86400

    def _purge(directory, prefix, suffix, key):
        removed = 0
        try:
            names = os.listdir(directory)
        except FileNotFoundError:
            return 0
        for fname in names:
            path = os.path.join(directory, fname)
            if not fname.startswith(prefix) or not fname.endswith(suffix):
                continue
            if prefix == 'session_' and fname == 'session_latest.json':
                continue                 # sessao corrente: nunca apagar
            try:
                if os.path.getmtime(path) < cutoff:
                    os.remove(path)
                    removed += 1
            except OSError as exc:       # noqa: PERF203
                logger.warning(f"[retencao] Nao foi possivel remover "
                               f"{fname}: {exc}")
        return removed

    summary['sessions'] = _purge(DATA_DIR, 'session_', '.json', 'sessions')
    summary['workflows'] = _purge(DATA_DIR, 'workflow_', '.json', 'workflows')
    summary['pdfs'] = _purge(EXPORT_DIR, '', '.pdf', 'pdfs')

    total = summary['sessions'] + summary['workflows'] + summary['pdfs']
    if total:
        logger.info(f"[retencao] {total} arquivo(s) com mais de {days} dias "
                    f"removidos (sessoes: {summary['sessions']}, "
                    f"workflows: {summary['workflows']}, PDFs: {summary['pdfs']})")
    return summary


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s [%(levelname)s] %(message)s')
    print(cleanup_old_artifacts())
