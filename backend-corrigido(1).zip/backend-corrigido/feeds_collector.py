# -*- coding: utf-8 -*-
"""
Coletor de feeds RSS e Google News - 4root News.

  - UM UNICO pool de threads processa RSS + gnews juntos
  - requests.Session por thread (conexao reaproveitada, TLS mais rapido)
  - timeout HTTP reduzido (10s) e workers elevados (16)
  - Google News via RSS nativo (sem biblioteca gnews - mais rapido e estavel)
  - Extracao de data BS4 limitada (cap por feed) para nao travar o ciclo
  - Links do Google News resolvidos para a URL final do publisher

V2 - correcao do bug de links permutados
----------------------------------------
O bloco de resolucao agora:
  1. faz 2a tentativa so para os links que ficaram sem mapping
     (falha transitoria de rede/rate limit; o cache do resolver
     torna o retry barato);
  2. NUNCA troca um link gnews por outro link gnews (validacao
     defensiva);
  3. emite aviso no log quando o dominio final nao lembra a editora
     (visibilidade para anomalias; nao bloqueia a troca, porque ha
     editoras cujo nome legitimo difere do dominio).

V3 - higiene do Google News (limpeza do briefing)
------------------------------------------------
  1. resumo-eco eliminado: o <description> do RSS do Google News e
     apenas 'titulo + editora'; nesse caso o resumo fica vazio para
     o site e o PDF nao repetirem o titulo como se fosse texto;
  2. titulo limpo de verdade: aceita ' - ', en dash e em dash como
     separador e remove a editora que ficar colada no fim do titulo
     (caso 'Investing.com Brasil - Financas, ...');
  3. nome de editora normalizado: tira espacos sobrando, corta
     slogan apos ' - ', remove lixo tipo 'Home | ' e reduz nomes
     com caracteres CJK a parte latina (QB One/Sora do PDF nao tem
     glifos japoneses - 'NHKニュース' virava espacos em branco);
  4. mensagens de erro legiveis no status (o repr cru de tupla do
     requests aparecia truncado e estranho no PDF);
  5. retry automatico (1x) para falhas transitorias de rede na
     busca dos feeds (RemoteDisconnected/timeout do Google).

Fontes e palavras-chave ficam em config/feeds.yaml e config/keywords.yaml.

V4 - transporte HTTP endurecido (07/nov/2026)
---------------------------------------------
O Replit comecou a derrubar conexoes TLS no meio do handshake
(SSLEOFError / UNEXPECTED_EOF_WHILE_READING em ~1/3 das fontes,
incluindo todas as hospedadas no Google). Diagnostico: os MESMOS
feeds respondem 200 de uma rede neutra - o problema e o egress do
host, nao o codigo. A busca HTTP agora mora em http_client.py:
  1. TLS limitado a 1.2 (evita patologias de TLS 1.3 em middlebox);
  2. 3 tentativas com backoff exponencial e CONEXAO NOVA por
     tentativa (socket envenenado nao recontamina a retry);
  3. ultima tentativa via curl_cffi impersonando Chrome (stack TLS
     de browser atravessa middleboxes que cortam a do Python);
  4. timeout connect/read separados (10s handshake, 15s leitura);
  5. escape hatch PROXY_URL (env) caso o IP de saida queime.
"""
import re
import os
import json
import html
import time
import unicodedata
import logging
import concurrent.futures as cf
from datetime import datetime, timedelta, timezone
from urllib.parse import quote_plus, urljoin, urlparse

import yaml
import feedparser
import requests
from bs4 import BeautifulSoup

from config import (DATA_DIR, FEEDS_CONFIG_FILE, KEYWORDS_CONFIG_FILE,
                    NEWS_WINDOW_HOURS, COLLECT_WORKERS,
                    MAX_PER_FEED, MAX_SUMMARY, BS4_DATE_CAP, now_local)
from http_client import http_get  # transporte endurecido: TLS1.2 + retry + fallback

logger = logging.getLogger(__name__)


# ================================================================ configs
def _load_yaml(path):
    """Le arquivo YAML de configuracao (retorna {} se ausente)."""
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f) or {}
    except FileNotFoundError:
        return None
    except yaml.YAMLError as exc:
        logger.error(f"YAML invalido em {os.path.basename(path)}: {exc}")
        return None


# Campos obrigatorios e opcionais por tipo de fonte (documentados no README)
_SOURCE_RULES = {
    'rss':   {'required': ('url',),  'optional': ('note', 'enabled', 'name')},
    'gnews': {'required': ('query',), 'optional': ('language', 'country',
                                                   'max_results', 'period',
                                                   'note', 'enabled', 'name')},
}


def _validate_source(kind, src, where):
    """Valida UMA fonte adicionada (a mao ou nao) ao config/feeds.yaml.

    Retorna (fonte_normalizada, None) se valida ou (None, motivo) se
    invalida. O motivo e logado como aviso para o usuario corrigir.
    """
    if not isinstance(src, dict):
        return None, 'entrada nao e um dicionario YAML (verifique indentacao)'

    rules = _SOURCE_RULES[kind]
    name = str(src.get('name') or '').strip() or kind.upper()

    for field in rules['required']:
        value = str(src.get(field) or '').strip()
        if not value:
            return None, f"campo obrigatorio '{field}' ausente/vazio"
        src[field] = value

    if 'url' in src and not src['url'].lower().startswith(('http://', 'https://')):
        return None, f"url deve comecar com http(s):// (recebido: {src['url'][:60]})"

    if kind == 'gnews':
        try:
            src['max_results'] = max(1, min(50, int(src.get('max_results', 10))))
        except (TypeError, ValueError):
            src['max_results'] = 10
        src['language'] = str(src.get('language') or 'pt').lower()[:2]
        src['country'] = str(src.get('country') or 'BR').upper()[:2]
        if src.get('period'):
            src['period'] = str(src['period']).strip()

    src['enabled'] = bool(src.get('enabled', True))
    src.setdefault('name', name)
    return src, None


def _collect_valid_sources(data, kind, issues):
    """Extrai e valida a lista de fontes de uma secao do feeds.yaml."""
    valid, seen = [], set()
    for idx, src in enumerate(data.get(kind, []) or []):
        where = f"{kind}[{idx}]"
        clean, error = _validate_source(kind, dict(src or {}), where)
        if error:
            label = (src.get('name', 'sem nome')
                     if isinstance(src, dict) else 'entrada invalida')
            issues.append(f"{where} ({label}): {error}")
            continue
        # chave de deduplicacao: mesma url/query repetida entra uma vez
        key = (kind, (clean.get('url') or clean.get('query') or '').strip().lower())
        if key in seen:
            issues.append(f"{where} ({clean.get('name')}): duplicada - ignorada")
            continue
        seen.add(key)
        valid.append(clean)
    return valid


def load_sources():
    """Le config/feeds.yaml, valida e retorna (rss, gnews) enabled=true.

    Fontes NOVAS adicionadas pelo usuario sao aceitas automaticamente:
    o validador aplica defaults nos campos opcionais e avisa no log
    (com a posicao exata no arquivo) quando alguma entrada e invalida.
    """
    data = _load_yaml(FEEDS_CONFIG_FILE)
    if data is None:
        logger.warning('config/feeds.yaml nao encontrado - usando listas vazias.')
        return [], []

    issues = []
    rss = _collect_valid_sources(data, 'rss', issues)
    gnews = _collect_valid_sources(data, 'gnews', issues)

    for issue in issues:
        logger.warning(f"config/feeds.yaml - fonte ignorada: {issue}")

    total = len(rss) + len(gnews)
    logger.info(f"config/feeds.yaml: {total} fontes validas "
                f"({len(rss)} RSS, {len(gnews)} gnews)"
                + (f" | {len(issues)} entrada(s) invalida(s) ignorada(s)" if issues else ""))

    enabled = lambda lst: [f for f in lst if f.get('enabled', True)]  # noqa: E731
    return enabled(rss), enabled(gnews)


def load_keyword_config():
    """Le config/keywords.yaml e retorna dict com filtro de relevancia."""
    defaults = {
        'window_hours': NEWS_WINDOW_HOURS,
        'keywords': [], 'blocklist': [], 'override': [],
    }
    data = _load_yaml(KEYWORDS_CONFIG_FILE)
    if data is None:
        logger.warning('config/keywords.yaml nao encontrado - sem filtro de keywords.')
        return defaults
    defaults['window_hours'] = int(data.get('window_hours', NEWS_WINDOW_HOURS))
    defaults['keywords'] = [k.lower() for k in data.get('keywords', [])]
    defaults['blocklist'] = [b.lower() for b in data.get('blocklist', [])]
    defaults['override'] = [o.lower() for o in data.get('override', [])]
    return defaults


# ================================================================ filtro
def is_relevant(text, keywords, blocklist, override):
    """Keyword obrigatoria + blocklist com excecao de override (regra original)."""
    if not text:
        return False
    text_lower = text.lower()

    if not any(kw in text_lower for kw in keywords):
        return False

    if any(bk in text_lower for bk in blocklist):
        if not any(ov in text_lower for ov in override):
            logger.debug(f"Bloqueado pela blocklist: {text_lower[:80]}")
            return False

    return True


# ================================================================ datas
def parse_rss_date(entry):
    """Extrai data de uma entrada RSS/Atom."""
    for key in ['published_parsed', 'updated_parsed', 'created_parsed']:
        parsed = entry.get(key)
        if parsed:
            try:
                return datetime(*parsed[:6], tzinfo=timezone.utc)
            except (TypeError, ValueError):
                continue
    return None


def _parse_date_string(s):
    """Converte varios formatos de data string em datetime (respeita o offset quando presente)."""
    try:
        from dateutil import parser as _dparser
    except ImportError:
        _dparser = None

    if not s:
        return None
    s = s.strip()
    if not s:
        return None

    # Remove apenas fracoes de segundo (strptime nao suporta).
    # O offset de fuso (ex: -03:00) e PRESERVADO -- nunca descartar.
    s = re.sub(r'\.\d+$', '', s).strip()

    formats = [
        # ISO 8601 com offset (ex: 2026-10-23T17:47:00-03:00)
        '%Y-%m-%dT%H:%M:%S%z',
        '%Y-%m-%dT%H:%M:%S%Z',
        '%Y-%m-%dT%H:%M:%S',
        '%Y-%m-%d %H:%M:%S%z',
        '%Y-%m-%d %H:%M:%S',
        '%Y-%m-%d',
        # RFC 822 (pubDate de RSS, ex: Fri, 23 Oct 2026 20:47:00 GMT)
        '%a, %d %b %Y %H:%M:%S %z',
        '%a, %d %b %Y %H:%M:%S %Z',
        '%A, %d %B %Y %H:%M:%S %z',
        # formatos BR
        '%d/%m/%Y %H:%M:%S',
        '%d/%m/%Y %H:%M',
        '%d/%m/%Y',
        '%d/%m/%y',
    ]
    for fmt in formats:
        try:
            dt = datetime.strptime(s, fmt)
        except (ValueError, TypeError):
            continue
        if dt.tzinfo is None:
            # string sem fuso declarado: assume UTC (comportamento anterior)
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)

    if _dparser:
        try:
            dt = _dparser.parse(s, fuzzy=True, dayfirst=True)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc)
        except Exception:  # noqa: BLE001
            pass
    return None



def _extract_date_from_html(html, url=''):
    """Extrai data da pagina via BS4 (meta tags, <time>, classes CSS)."""
    try:
        soup = BeautifulSoup(html, 'lxml')
    except Exception:  # noqa: BLE001
        return None

    for meta_name in ['article:published_time', 'datePublished', 'pubdate',
                      'dc.date.issued', 'PublishDate']:
        meta = soup.find('meta', attrs={'property': meta_name}) or \
               soup.find('meta', attrs={'name': meta_name})
        if meta and meta.get('content'):
            d = _parse_date_string(meta['content'])
            if d:
                return d

    for time_tag in soup.find_all('time'):
        dt_attr = time_tag.get('datetime') or time_tag.get('data-hora')
        if dt_attr:
            d = _parse_date_string(dt_attr)
            if d:
                return d
        text = time_tag.get_text(strip=True)
        if text:
            d = _parse_date_string(text)
            if d:
                return d

    for cls in ['post-date', 'entry-date', 'published-date', 'post-published',
                'article-date', 'post__date', 'meta-date',
                'article__meta-date', 'content-header__date', 'meta__date',
                'author-date', 'post__meta-item--date', 'article__dateline']:
        el = soup.find(class_=cls)
        if el:
            d = _parse_date_string(el.get_text(strip=True))
            if d:
                return d

    return None


def _fetch_date_via_bs4(url):
    """GET na URL e extrai a data real da pagina (com retries do http_client)."""
    try:
        resp = http_get(url)
        if resp.status_code != 200:
            return None
        return _extract_date_from_html(resp.text, url)
    except Exception:  # noqa: BLE001
        return None


def _extract_date_from_url(url):
    """Extrai data de URLs no formato /YYYY/MM/DD/."""
    m = re.search(r'/(\d{4})/(\d{2})/(\d{2})(?:/|\Z)', url)
    if m:
        try:
            return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)),
                            tzinfo=timezone.utc)
        except ValueError:
            pass
    return None


# ================================================================ imagens
def _extract_image_from_entry(entry, base_url=''):
    """Extrai a URL da imagem de um entry feedparser (media/enclosure/summary)."""
    try:
        for key in ('media_thumbnail', 'media_content'):
            media = entry.get(key) or []
            for m in media:
                url = m.get('url', '')
                if url and url.startswith('http'):
                    return url
        for enc in entry.get('enclosures', []) or []:
            etype = enc.get('type', '')
            url = enc.get('href', '') or enc.get('url', '')
            if url and ('image' in etype or url.lower().endswith(('.jpg', '.jpeg', '.png', '.webp'))):
                return url
    except Exception:  # noqa: BLE001
        pass
    # fallback: primeira <img> do summary/conteudo
    for field in ('summary', 'content:encoded', 'content'):
        raw = entry.get(field)
        if isinstance(raw, list):
            raw = ''.join(part.get('value', '') for part in raw)
        if raw:
            m = re.search(r'<img[^>]+src=["\']([^"\']+)["\']', raw, re.IGNORECASE)
            if m:
                url = urljoin(base_url, m.group(1).strip())
                if url.startswith('http'):
                    return url
    return ''


# ================================================================ sessoes
def _new_article(title, summary, link, source, art_type, pub_date, image=''):
    # html.unescape corrige entidades duplamente escapadas de alguns feeds
    # (ex.: '&amp;#x5b;' viraria '&#x5b;' na tela; agora vira '[')
    return {
        'title': html.unescape(title or '').strip(),
        'summary': html.unescape((summary or ''))[:MAX_SUMMARY],
        'link': link,
        'source': source,
        'type': art_type,
        'published': pub_date.isoformat(),
        'collected_at': datetime.now(timezone.utc).isoformat(),
        'image': (image or '')[:600],
    }


# ================================================================ RSS
def _get_with_retry(url, attempts=None, backoff=None):
    """GET endurecido (delega ao http_client).

    3 tentativas com backoff exponencial, conexao NOVA a cada retry,
    TLS limitado a 1.2 e, esgotadas as retries, tentativa final via
    curl_cffi impersonando Chrome (ve http_client.http_request).
    Erros HTTP 4xx/5xx NAO sao reintentados: o codigo de status volta
    para o fluxo normal. Params attempts/backoff mantidos na assinatura
    por compatibilidade (ignorados - o transporte le config.py).
    """
    return http_get(url, attempts=attempts)


def _friendly_error(exc):
    """Mensagem de erro curta e legivel para o status da fonte.

    Substitui o repr cru das excecoes do requests (ex.:
    "('Connection aborted.', RemoteDisconnected(...))") que aparecia
    truncado e sem sentido no PDF do briefing.
    """
    if isinstance(exc, requests.exceptions.Timeout):
        return 'tempo esgotado - nova tentativa no proximo ciclo'
    if isinstance(exc, requests.exceptions.SSLError):
        # tipico de egress com TLS cortado no meio do handshake
        # (Replit/proxy); o http_client ja aplicou retries + fallback
        return 'TLS interrompido no caminho (apos retries + fallback)'
    if isinstance(exc, requests.exceptions.ConnectionError):
        return 'conexao interrompida - transitorio, nova tentativa no proximo ciclo'
    msg = re.sub(r'\s+', ' ', str(exc)).strip()
    if not msg or msg.startswith("('"):
        msg = exc.__class__.__name__
    return msg[:90]


def _collect_single_rss(feed_config, cutoff, keywords, blocklist, override):
    """Coleta UM feed RSS (roda em thread). Retorna (artigos, status)."""
    feed_name = feed_config.get('name', 'sem nome')
    feed_url = feed_config['url']
    articles = []
    try:
        resp = _get_with_retry(feed_url)
        if resp.status_code != 200:
            return articles, {'name': feed_name, 'status': 'error',
                              'message': f'HTTP {resp.status_code}'}

        feed = feedparser.parse(resp.content)
        if feed.bozo and not feed.entries:
            return articles, {'name': feed_name, 'status': 'error',
                              'message': str(feed.bozo)[:100]}

        bs4_used = 0   # cap: no maximo BS4_DATE_CAP buscas de data por feed
        for entry in feed.entries:
            if len(articles) >= MAX_PER_FEED:
                break
            link = entry.get('link', '')
            title = entry.get('title', '')
            summary = entry.get('summary', '')

            if summary:
                summary = BeautifulSoup(summary, 'lxml').get_text(
                    separator=' ', strip=True)
            summary = summary[:MAX_SUMMARY]

            # filtragem rapida ANTES de qualquer requisicao extra
            if not is_relevant(f'{title} {summary}', keywords, blocklist, override):
                continue

            pub_date = parse_rss_date(entry) or _extract_date_from_url(link)

            if not pub_date and link and bs4_used < BS4_DATE_CAP:
                bs4_used += 1
                pub_date = _fetch_date_via_bs4(link)
                if pub_date:
                    logger.info(f"Data extraida via BS4 da pagina: {pub_date} - {title[:50]}")

            if pub_date and pub_date < cutoff:
                continue
            if not pub_date:
                logger.debug(f"Descartado (sem data): {title[:60]}")
                continue

            image = _extract_image_from_entry(entry, base_url=link)
            articles.append(_new_article(title, summary, link, feed_name,
                                         'rss', pub_date, image=image))

        return articles, {'name': feed_name, 'status': 'ok',
                          'articles': len(articles)}

    except Exception as exc:  # noqa: BLE001
        logger.error(f"Erro ao coletar {feed_name}: {exc}")
        return articles, {'name': feed_name, 'status': 'error',
                          'message': _friendly_error(exc)}


# ================================================================ gnews (Google News RSS)
GNEWS_RSS_URL = ('https://news.google.com/rss/search?q={query}'
                 '&hl={hl}&gl={gl}&ceid={ceid}')

# Pausa antes da 2a tentativa quando o Google News responde 429 (rate
# limit do IP de saida). O volume do sistema depende massivamente das
# queries gnews (~88% dos artigos num ciclo saudavel): quando o Google
# limita o IP compartilhado do host, TODAS as 7 queries voltam vazias
# e o ciclo colapsa para os poucos artigos de RSS direto. Uma unica
# pausa+retry resolve os casos de rajada transitoria (os definitivos,
# de IP queimado por horas, continuam visiveis no log e no status).
_GNEWS_429_PAUSE = 20


def _gnews_rss_url(src):
    """Monta a URL de RSS do Google News para uma consulta."""
    lang = (src.get('language') or 'pt').lower()
    country = (src.get('country') or 'BR').upper()
    if lang == 'pt' and country == 'BR':
        hl, gl, ceid = 'pt-BR', 'BR', 'BR:pt-419'
    else:
        hl = f"{lang}-{country}"
        gl = country
        ceid = f"{country}:{lang}"
    query = src['query']
    period = src.get('period')
    if period:
        query = f"{query} when:{period}"
    return GNEWS_RSS_URL.format(query=quote_plus(query), hl=hl, gl=gl, ceid=ceid)


# ----------------------------------------------------------------
# Higiene de titulo/editora/resumo do Google News (V3)
# ----------------------------------------------------------------
_RE_CJK = re.compile(u'[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\u3000-\u303f]')
_RE_SPACES = re.compile(r'\s+')
_RE_TAIL_SEPS = re.compile(r'[\s\-–—]+$')
# Google News usa ' - ' na maioria; ha registros com en dash/em dash.
_GNEWS_SEPARATORS = (' - ', ' – ', ' — ')


def _clean_publisher(name, fallback=''):
    """Normaliza o nome da editora vindo do <source> do RSS do GNews.

    - colapsa espacos/quebras sobrando ('NHK       ' -> 'NHK');
    - nomes com CJK (kanji/kana) viram so a parte latina, porque as
      fontes do PDF (QB One/Sora) nao tem glifos japoneses e o nome
      'NHKニュース' imprimia como espaços em branco;
    - corta slogan apos ' - ' ('Investing.com Brasil - Financas,
      Cambio e Investimentos' -> 'Investing.com Brasil');
    - remove prefixo de lixo tipo 'Home | '.
    """
    name = _RE_SPACES.sub(' ', str(name or '')).strip()
    if not name:
        return fallback
    if _RE_CJK.search(name):
        latin = ' '.join(re.findall(r'[A-Za-z0-9][A-Za-z0-9 .&\-]*', name))\
            .strip(' -|')
        if len(latin) >= 2:
            name = _RE_SPACES.sub(' ', latin).strip()
        else:
            return fallback
    if len(name) > 28 and ' - ' in name:
        head = name.rsplit(' - ', 1)[0].strip()
        if len(head) >= 3:
            name = head
    if name.lower().startswith('home | '):
        name = name[7:].strip()
    return name or fallback


def _split_gnews_title(raw_title):
    """Separa 'Titulo - Editora' aceitando hifen, en dash e em dash."""
    title, publisher = raw_title, ''
    for sep in _GNEWS_SEPARATORS:
        if sep not in title:
            continue
        head, _, tail = title.rpartition(sep)
        if head and tail and len(tail) <= 60:
            title, publisher = head, tail
            break
    return title, publisher


def _strip_publisher_suffix(title, publisher):
    """Remove a editora que ficou colada no fim do titulo.

    Cobre o caso de titulo em cadeia ('... - Investing.com Brasil'
    quando o <source> traz 'Investing.com Brasil - Financas, ...').
    Comparacao sem acento/caixa para ser tolerante a variacoes.
    """
    p_norm = _norm_txt(publisher)
    if not title or not p_norm:
        return title
    for _ in range(3):  # pode haver mais de um sufixo encadeado
        head_found = None
        for sep in _GNEWS_SEPARATORS:
            head, _, tail = title.rpartition(sep)
            if not head:
                continue
            t_norm = _norm_txt(tail)
            if t_norm == p_norm or (len(t_norm) >= 3
                                    and p_norm.endswith(t_norm)):
                head_found = head
                break
        if head_found is None:
            break
        title = _RE_TAIL_SEPS.sub('', head_found)
    return title


def _kill_summary_echo(title, summary, publisher=''):
    """Anula o resumo-eco do Google News (retorna '' se for eco).

    O <description> do RSS do Google News nao e texto da materia: e
    apenas 'titulo + editora' (ancora do link). Sem esta limpeza, o
    site e o PDF mostravam o titulo duplicado com o nome da fonte
    colado no final (ex.: '... return after cyberattack WBAL-TV').
    """
    s = _RE_SPACES.sub(' ', str(summary or '')).strip()
    if not s:
        return ''
    t = _RE_SPACES.sub(' ', str(title or '')).strip()
    p = _RE_SPACES.sub(' ', str(publisher or '')).strip()
    t_norm, p_norm = _norm_txt(t), _norm_txt(p)
    s_norm = _norm_txt(s)
    if not t_norm:
        return s
    if s_norm == t_norm or s_norm == f'{t_norm} {p_norm}'.strip():
        return ''
    if s_norm.startswith(t_norm):
        rest = s_norm[len(t_norm):].strip(' \t-–—|')
        # lixo de prefixo do proprio GNews (ex. 'Home | FSA')
        if rest.startswith('home | '):
            rest = rest[7:].strip(' \t-–—|')
        # resto vazio ou composto apenas pela editora (ou variacao dela,
        # ex. 'investing.com brasil - financas, cambio e...' quando a
        # editora normalizada e 'investing.com brasil') = eco
        if not rest:
            return ''
        if p_norm and (rest == p_norm or rest.startswith(p_norm)
                       or p_norm.endswith(rest)):
            return ''
    return s


def _collect_single_gnews(src, cutoff, keywords, blocklist, override):
    """Coleta UM topico do Google News via RSS (roda em thread)."""
    name = src.get('name', 'Google News')
    articles = []
    url = _gnews_rss_url(src)
    try:
        resp = _get_with_retry(url)
        if resp.status_code == 429:
            # Google News limitando o IP de saida: espera e tenta 1x de novo
            logger.warning(f"[gnews] HTTP 429 do Google News em '{name}' "
                           f"(rate limit do IP) - aguardando "
                           f"{_GNEWS_429_PAUSE}s e tentando 1x novamente")
            time.sleep(_GNEWS_429_PAUSE)
            resp = _get_with_retry(url)
        if resp.status_code != 200:
            msg = f'HTTP {resp.status_code}'
            if resp.status_code == 429:
                msg = ('HTTP 429 - Google News limitando este IP '
                       '(rate limit; volta sozinho apos algumas horas)')
            return articles, {'name': name, 'status': 'error',
                              'message': msg}

        feed = feedparser.parse(resp.content)
        max_results = int(src.get('max_results', 10))
        count = 0

        for entry in feed.entries:
            if count >= max_results or len(articles) >= MAX_PER_FEED:
                break

            raw_title = entry.get('title', '') or ''
            link = entry.get('link', '') or ''
            if not raw_title or not link:
                continue

            # Google News: "Titulo da materia - Editora" (hifen,
            # en dash ou em dash)
            title, publisher = _split_gnews_title(raw_title)

            source_el = entry.get('source') or {}
            if isinstance(source_el, dict) and source_el.get('title'):
                publisher = _clean_publisher(source_el['title'],
                                             fallback=name)
            else:
                publisher = _clean_publisher(publisher)

            # remove a editora que ficou colada no fim do titulo
            title = _strip_publisher_suffix(title, publisher).strip()

            summary_raw = entry.get('summary', '') or ''
            if summary_raw:
                summary_raw = BeautifulSoup(summary_raw, 'lxml').get_text(
                    separator=' ', strip=True)
            # o description do GNews e eco do titulo -> vira ''
            summary_raw = _kill_summary_echo(title, summary_raw,
                                             publisher)[:MAX_SUMMARY]

            if not is_relevant(f'{title} {summary_raw}', keywords,
                               blocklist, override):
                continue

            pub_date = parse_rss_date(entry) or _extract_date_from_url(link)
            if not pub_date:
                # Google News sempre envia pubDate; sem data = descarta
                continue
            if pub_date < cutoff:
                continue

            source_name = publisher or name
            articles.append(_new_article(title, summary_raw, link,
                                         source_name, 'gnews', pub_date))
            count += 1

        return articles, {'name': name, 'status': 'ok' if articles else 'no_results',
                          'articles': len(articles)}

    except Exception as exc:  # noqa: BLE001
        logger.error(f"[GNews] Erro em {name}: {exc}")
        return articles, {'name': name, 'status': 'error',
                          'message': _friendly_error(exc)}


# ================================================================ validacao de links resolvidos (V2)
def _norm_txt(s):
    """Minusculas sem acento, para comparar editora vs dominio."""
    s = unicodedata.normalize('NFKD', str(s or '').lower())
    return ''.join(c for c in s if not unicodedata.combining(c))


def _warn_source_mismatch(art, final_url):
    """Aviso informativo quando o dominio final nao lembra a editora.

    NAO bloqueia a troca (ha editoras cujo nome legitimo difere do
    dominio, ex. 'National Cybersecurity Alliance' -> staysafeonline.org).
    Serve apenas para dar visibilidade a anomalias no log do ciclo.
    """
    src = _norm_txt(art.get('source', ''))
    try:
        host = _norm_txt((urlparse(final_url).hostname or '').lower()
                         .replace('www.', ''))
    except ValueError:
        return
    if not src or not host:
        return
    tokens = [t for t in re.split(r'[^a-z0-9]+', src) if len(t) >= 3]
    if tokens and not any(t in host for t in tokens):
        logger.info(f"[gnews] conferir par editora/dominio: "
                    f"'{art.get('source')}' -> {host} "
                    f"(titulo: {str(art.get('title', ''))[:50]})")


# ================================================================ principal
def collect_all():
    """Coleta TODAS as fontes (RSS + Google News) em UM pool de threads."""
    rss_feeds, gnews_sources = load_sources()
    kw = load_keyword_config()
    window_hours = kw['window_hours']
    keywords, blocklist, override = kw['keywords'], kw['blocklist'], kw['override']

    total_sources = len(rss_feeds) + len(gnews_sources)
    logger.info(f"Iniciando coleta paralela (janela: {window_hours}h, "
                f"{min(COLLECT_WORKERS, max(1, total_sources))} workers)...")
    logger.info(f"Fontes: {len(rss_feeds)} RSS | {len(gnews_sources)} gnews")
    cutoff = datetime.now(timezone.utc) - timedelta(hours=window_hours)

    feed_status, gnews_status = [], []
    all_articles = []

    tasks = ([('rss', cfg) for cfg in rss_feeds]
             + [('gnews', cfg) for cfg in gnews_sources])

    def _dispatch(kind, cfg):
        if kind == 'rss':
            return _collect_single_rss(cfg, cutoff, keywords, blocklist, override)
        return _collect_single_gnews(cfg, cutoff, keywords, blocklist, override)

    if tasks:
        workers = min(COLLECT_WORKERS, len(tasks))
        with cf.ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(_dispatch, kind, cfg): (kind, cfg)
                       for kind, cfg in tasks}
            for fut in cf.as_completed(futures):
                kind, cfg = futures[fut]
                try:
                    result = fut.result()
                except Exception as exc:  # noqa: BLE001
                    result = ([], {'name': cfg.get('name', '?'),
                                   'status': 'error',
                                   'message': _friendly_error(exc)})
                arts, status = result
                all_articles.extend(arts)

                if kind == 'rss':
                    feed_status.append(status)
                else:
                    gnews_status.append(status)

    feed_status.sort(key=lambda s: s['name'].lower())
    gnews_status.sort(key=lambda s: s['name'].lower())

    # Resumo de fontes no log: mostra na hora QUANDO um ciclo vem vazio
    # (ex.: 9 artigos em 12s = massa de fontes falhando rapido), sem
    # depender da bolha de status da interface.
    _ok = sum(1 for s in feed_status + gnews_status if s.get('status') == 'ok')
    _nores = sum(1 for s in feed_status + gnews_status
                 if s.get('status') == 'no_results')
    _tot = len(feed_status) + len(gnews_status)
    logger.info(f"[coleta] fontes consultadas: {_tot} | ok: {_ok} | "
                f"sem itens novos: {_nores} | com erro: {_tot - _ok - _nores}")

    # -----------------------------------------------------------
    # Resolver links do Google News para a URL FINAL do publisher.
    # O site e o PDF nunca devem apontar para news.google.com.
    # (roda ANTES da dedup: links finais iguais se fundem corretamente)
    #
    # V2: retry barato para falhas transitorias, validacao defensiva
    # (nunca trocar gnews por gnews) e aviso de anomalia editora/dominio.
    # -----------------------------------------------------------
    try:
        from gnews_resolver import resolve_links, is_gnews_link
        gnews_links = [a['link'] for a in all_articles
                       if a.get('type') == 'gnews' and is_gnews_link(a.get('link', ''))]
        if gnews_links:
            t0 = time.time()
            mapping = resolve_links(gnews_links)

            # 2a tentativa SO para os que ficaram sem mapping (falha
            # transitoria de rede/rate limit). O cache do resolver faz
            # com que os ja resolvidos custem zero aqui.
            ainda_pendentes = [u for u in gnews_links if u not in mapping]
            if ainda_pendentes:
                logger.info(f"[gnews] {len(ainda_pendentes)} links sem "
                            f"resolucao - 2a tentativa")
                time.sleep(2)
                mapping.update(resolve_links(ainda_pendentes))

            trocados, rejeitados = 0, 0
            for art in all_articles:
                final = mapping.get(art.get('link', ''))
                if not final or final == art.get('link'):
                    continue
                if is_gnews_link(final):
                    # defensivo: jamais trocar um gnews por outro gnews
                    rejeitados += 1
                    continue
                _warn_source_mismatch(art, final)
                art['link'] = final
                art['link_resolved'] = True
                trocados += 1
            logger.info(f"[gnews] {trocados} links apontam para a fonte final "
                        f"({time.time() - t0:.1f}s)"
                        + (f" | {rejeitados} trocas rejeitadas na validacao"
                           if rejeitados else ""))
    except Exception as exc:  # noqa: BLE001
        dica = ""
        if isinstance(exc, (SyntaxError, IndentationError)):
            # copy/paste no editor do Replit corrompe o arquivo sem que o
            # deploy falhe; o boot loga [self-check] com o arquivo culpado.
            dica = (" | ARQUIVO CORROMPIDO (sintaxe/indentacao): recopie "
                    "gnews_resolver.py do pacote (prefira UPLOAD a "
                    "copy/paste) e faca redeploy")
        logger.warning(f"[gnews] resolucao de links falhou (mantendo gnews): "
                       f"{exc}{dica}")

    # Transparencia: quantos artigos AINDA apontam para o Google News.
    # O site e o PDF mostram sempre art['link']; se a resolucao falhou
    # (ex. egress instavel), o usuario merece ver isso no log do ciclo.
    try:
        from gnews_resolver import is_gnews_link as _still_gnews
        restantes = sum(1 for a in all_articles
                        if a.get('type') == 'gnews'
                        and _still_gnews(a.get('link', '')))
        if restantes:
            logger.warning(f"[gnews] {restantes} artigo(s) seguem com link do "
                           f"Google News (resolucao nao chegou ao publisher; "
                           f"o cache persistente tenta de novo no proximo ciclo)")
    except Exception:  # noqa: BLE001
        pass

    # Remover duplicatas por link
    seen_links = set()
    unique_articles = []
    for art in all_articles:
        if art['link'] not in seen_links:
            seen_links.add(art['link'])
            unique_articles.append(art)

    # Ordenar por data (mais recente primeiro)
    unique_articles.sort(key=lambda x: x.get('published', ''), reverse=True)

    session_data = {
        'session_id': now_local().strftime('%Y%m%d_%H%M%S'),
        'collected_at': datetime.now(timezone.utc).isoformat(),
        'window_hours': window_hours,
        'total_articles': len(unique_articles),
        'feed_status': feed_status,
        'gnews_status': gnews_status,
        'articles': unique_articles,
    }

    data_path = os.path.join(DATA_DIR, 'session_latest.json')
    with open(data_path, 'w', encoding='utf-8') as f:
        json.dump(session_data, f, ensure_ascii=False, indent=2)

    logger.info(f"Coleta finalizada: {len(unique_articles)} artigos unicos")
    return session_data


def load_session(session_id=None):
    """Carrega dados de uma sessao."""
    if session_id:
        path = os.path.join(DATA_DIR, f'session_{session_id}.json')
    else:
        path = os.path.join(DATA_DIR, 'session_latest.json')
    if os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return None


def save_session(session_data):
    """Salva dados da sessao (arquivo da sessao + session_latest)."""
    session_id = session_data.get('session_id',
                                  now_local().strftime('%Y%m%d_%H%M%S'))
    path = os.path.join(DATA_DIR, f'session_{session_id}.json')
    path_latest = os.path.join(DATA_DIR, 'session_latest.json')
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(session_data, f, ensure_ascii=False, indent=2)
    with open(path_latest, 'w', encoding='utf-8') as f:
        json.dump(session_data, f, ensure_ascii=False, indent=2)
    return session_id


def list_sessions():
    """Lista todas as sessoes salvas."""
    sessions = []
    for fname in sorted(os.listdir(DATA_DIR), reverse=True):
        if fname.startswith('session_') and fname.endswith('.json') \
                and fname != 'session_latest.json':
            fpath = os.path.join(DATA_DIR, fname)
            try:
                with open(fpath, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    sessions.append({
                        'id': data.get('session_id', fname),
                        'date': data.get('collected_at', ''),
                        'total': data.get('total_articles', 0),
                        'pdf': data.get('pdf_file', ''),
                    })
            except Exception:  # noqa: BLE001
                pass
    return sessions