#!/usr/bin/env bash
# 4root News System - inicializacao
set -e
cd "$(dirname "$0")"

# Instalar dependencias (opcional em ambientes ja preparados)
if [ "$SKIP_INSTALL" != "1" ]; then
    pip install -r requirements.txt
fi

# Configuracao via variaveis de ambiente (padroes:
#   AUTO_COLLECT_ENABLED=1  AUTO_COLLECT_INTERVAL_HOURS=3  PORT=8000)
export PORT="${PORT:-8000}"

# Fuso do processo (log, nomes de sessao/PDF): America/Sao_Paulo.
# FORCA por cima do TZ=UTC que o container pode trazer; para outro fuso,
# defina APP_TZ. O app.py redefine TZ por garantia.
export TZ="${APP_TZ:-America/Sao_Paulo}"

echo "[4root//news] iniciando em 0.0.0.0:${PORT}"
exec python app.py
