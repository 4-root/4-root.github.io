# -*- coding: utf-8 -*-
"""
Coleta automatica em background.

Uma daemon-thread dispara o pipeline completo (coleta -> dedup -> selecao ->
export) a cada AUTO_COLLECT_INTERVAL_HOURS horas, sem travar o Flask.

Configuracao via variaveis de ambiente (ver config.py):
    AUTO_COLLECT_ENABLED=1          (liga/desliga o scheduler)
    AUTO_COLLECT_INTERVAL_HOURS=3   (intervalo entre ciclos)
    AUTO_COLLECT_ON_STARTUP=1       (roda um ciclo imediatamente ao iniciar)
"""
import threading
import logging
from datetime import datetime, timedelta

from config import (AUTO_COLLECT_ENABLED, AUTO_COLLECT_INTERVAL_HOURS,
                    AUTO_COLLECT_ON_STARTUP, now_local)

logger = logging.getLogger('scheduler')

_state = {
    'enabled': AUTO_COLLECT_ENABLED,
    'interval_hours': AUTO_COLLECT_INTERVAL_HOURS,
    'running': False,
    'last_run': None,
    'last_result': None,
    'next_run': None,
    'total_runs': 0,
    'total_errors': 0,
}
_lock = threading.Lock()
_thread = None


def _run_once(trigger='auto'):
    """Executa um ciclo do pipeline (bloqueante)."""
    from workflow.orchestrator import run_full_pipeline

    if _state['running']:
        logger.warning('[scheduler] Ciclo anterior ainda em execucao - ignorando.')
        return None

    with _lock:
        _state['running'] = True

    logger.info(f'[scheduler] Iniciando ciclo ({trigger})...')
    result = None
    try:
        result = run_full_pipeline()
        with _lock:
            _state['last_run'] = now_local().isoformat()
            _state['last_result'] = {
                'success': result.get('success', False),
                'articles': result.get('total_collected', 0),
                'errors': result.get('errors', []),
            }
            _state['total_runs'] += 1
            if not result.get('success'):
                _state['total_errors'] += 1
    except Exception as exc:  # noqa: BLE001
        logger.error(f'[scheduler] Erro no ciclo: {exc}', exc_info=True)
        with _lock:
            _state['last_run'] = now_local().isoformat()
            _state['last_result'] = {'success': False, 'error': str(exc)}
            _state['total_runs'] += 1
            _state['total_errors'] += 1
    finally:
        with _lock:
            _state['running'] = False
            _state['next_run'] = (
                now_local() + timedelta(hours=AUTO_COLLECT_INTERVAL_HOURS)
            ).isoformat()

    return result


def _loop():
    """Loop principal do scheduler."""
    if AUTO_COLLECT_ON_STARTUP:
        _run_once('startup')
    while True:
        # dorme em fatias de 30s (mais facil de interromper no shutdown)
        for _ in range(max(1, int(AUTO_COLLECT_INTERVAL_HOURS * 120))):
            threading.Event().wait(30)
        _run_once('auto')


def start_scheduler():
    """Inicia a daemon-thread do scheduler (idempotente)."""
    global _thread
    if not AUTO_COLLECT_ENABLED:
        logger.info('[scheduler] Coleta automatica desabilitada '
                    '(AUTO_COLLECT_ENABLED=0).')
        return

    if _thread is not None and _thread.is_alive():
        return

    if AUTO_COLLECT_INTERVAL_HOURS <= 0:
        logger.warning('[scheduler] Intervalo invalido - scheduler nao iniciado.')
        return

    _thread = threading.Thread(target=_loop, daemon=True, name='auto-collect')
    _thread.start()
    with _lock:
        _state['next_run'] = (
            now_local() + timedelta(hours=AUTO_COLLECT_INTERVAL_HOURS)
        ).isoformat()
    logger.info(f'[scheduler] Coleta automatica ativa - ciclo a cada '
                f'{AUTO_COLLECT_INTERVAL_HOURS}h.')


def status():
    """Estado atual do scheduler (para a interface)."""
    return dict(_state)
