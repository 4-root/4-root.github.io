# #_4root // news — Pacote BACKEND/API (Replit)

Este pacote é **só a funcionalidade**: API Flask que coleta as fontes,
deduplica/ranqueia, gera as notícias e os PDFs do ciclo, e serve tudo para
o frontend estático publicado no GitHub Pages.

```
app.py                 API: /data/news.json · /export/<pdf> · POST /collect
scheduler.py           coleta automática em background — ciclo a cada 3h
feeds_collector.py     coleta paralela RSS + Google News (16 workers)
briefing_generator.py  PDF do ciclo (ReportLab, capa branco + QB One)
gnews_resolver.py      resolve o link original do Google News
publisher.py           monta o JSON público consumido pelo frontend
maintenance.py         retenção: mantém 6 dias de sessões/logs/PDFs
workflow/              pipeline (coleta → dedup/rank → export)
config/                feeds.yaml + keywords.yaml (fontes e keywords — editáveis)
templates/             páginas de erro (404/500)
static/fonts/          QB One + Sora (usadas no PDF)
wsgi.py                inicialização de produção via Gunicorn
requirements.txt       dependências Python da API
```

**O que roda sozinho:** no início da API sobe o primeiro ciclo; depois, o
scheduler repete **a cada 3 horas**. O botão "executar workflow" do site
dispara uma coleta manual — aceita só depois de **1h** da última coleta.

---

## Execução no Replit

Este backend roda pelo serviço `API Server` do projeto. Em desenvolvimento,
o serviço usa `app.py`; em produção, usa Gunicorn com um processo para evitar
que o scheduler inicie ciclos duplicados.

## Conectar o site

Depois de publicar o serviço, copie a URL pública do Replit e configure-a
como base no `index.html` do frontend estático:

```html
<script>window.NEWS_API_BASE = 'https://SUA-URL-DO-REPLIT';</script>
```

O JSON informa `api_base` automaticamente usando o domínio público do Replit.
`PUBLIC_API_URL` pode ser definida para substituir esse domínio caso exista um
domínio próprio.

> **CORS** está liberado somente para `https://news.4root.com.br`.

## PASSO 3 — Manter a API acordada (IMPORTANTE)

O scheduler vive **dentro do processo da API**: se o app dormir, o ciclo de
3h para. No Replit:

- **Plano free**: o workspace adormece após um tempo sem uso — o ciclo de
  3h só roda com a aba aberta/uso recente. Para produção 24/7 é preciso
  **Deployments** (Reserved VM mantém o processo sempre ativo — plano pago).
- **Atalho while free**: um ping externo (ex.: UptimeRobot batendo em
  `SUA-URL/` a cada 5 min) ajuda a manter o workspace desperto, mas não é
  garantia oficial do Replit.
- Alternativa sem custo: rodar este mesmo pacote num VPS/servidor próprio
  (`python3 app.py` + `PORT=8000`) — comportamento idêntico.

## Variáveis de ambiente (todas opcionais — padrões já corretos)

| Variável                      | Padrão | O que faz                                  |
|-------------------------------|--------|--------------------------------------------|
| `AUTO_COLLECT_INTERVAL_HOURS` | `3`    | intervalo do ciclo automático              |
| `AUTO_COLLECT_ENABLED`        | `1`    | liga/desliga o scheduler                   |
| `AUTO_COLLECT_ON_STARTUP`     | `1`    | coleta imediata ao iniciar                 |
| `COLLECT_COOLDOWN_SECONDS`    | `3600` | cooldown do botão (1h)                     |
| `RETENTION_DAYS`              | `6`    | dias de sessões/logs/PDFs guardados        |
| `PUBLIC_API_URL`              | —      | sobrescreve a base informada no JSON       |
| `PORT`                        | `8000` | porta (Replit injeta a dela)               |
| `COLLECT_WORKERS`             | `16`   | threads de coleta paralela                 |

## Endpoints da API

| Rota                 | Método | Descrição                                   |
|----------------------|--------|---------------------------------------------|
| `/`                  | GET    | página de status (mostra a URL pública)     |
| `/healthz`           | GET    | verificação de saúde do serviço             |
| `/data/news.json`    | GET    | dados do ciclo (o que o frontend consome)   |
| `/export/<pdf>`      | GET    | PDFs de cada ciclo (6 dias de retenção)     |
| `/collect`           | POST   | coleta manual (cooldown 1h → 429 com retry) |

## Fontes e keywords (sem tocar em código)

- `config/feeds.yaml` — RSS e Google News monitorados (edite e salve; entra
  no próximo ciclo automaticamente).
- `config/keywords.yaml` — palavras-chave, janela de notícias (`window_hours`,
  padrão 24h) e limites.

## Modo dev (site na mesma origem)

Para executar localmente fora do serviço, rode `python3 app.py` dentro desta
pasta; a API escuta na porta definida em `PORT` (padrão `8000`).
