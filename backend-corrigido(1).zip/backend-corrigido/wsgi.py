"""Gunicorn entry point for the 4root News API."""

from app import app, start_background_services

start_background_services()
