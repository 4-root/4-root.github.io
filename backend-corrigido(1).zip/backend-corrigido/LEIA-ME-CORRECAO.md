# CORREÇÃO DA COLETA — 07/nov/2026

## 09/nov (5ª) — Seu log de 00:46 confirmou o boot resiliente; 2 arquivos seguem corrompidos no Replit + 1 defeito encontrado NO PRÓPRIO PACOTE (corrigido)

### O que o seu log de 00:46 UTC mostra — as duas faces

**A boa notícia (a correção estrutural funcionou):** o worker do gunicorn
NÃO crashou mais. O deploy subiu (`Deployment successful`), o `/healthz`
passou a responder 200 e o sistema entrou em modo degradado com diagnóstico
no log — exatamente o comportamento projetado na atualização anterior. O
loop infinito de healthcheck 500 acabou.

**A má notícia (a causa continua lá):** os dois arquivos seguem corrompidos
NO SEU REPLIT — e o erro é inequívoco:

```
[boot] modulo 'feeds_collector' falhou ao importar: ARQUIVO CORROMPIDO
       (sintaxe/indentacao, linha 2: unexpected indent)
[boot] modulo 'gnews_resolver' falhou ao importar: ARQUIVO CORROMPIDO
       (sintaxe/indentacao, linha 2: unexpected indent)
[self-check] 2/15 modulos corrompidos
```

`linha 2: unexpected indent` nos dois arquivos é a assinatura exata do
**copy/paste no editor** (o editor indenta a 2ª linha do texto colado). Os
arquivos deste pacote estão íntegros — o que está quebrado é a cópia que
chegou lá. O `publisher` falhou por efeito cascata (ele importa um dos dois
arquivos quebrados); o `[cooldown] Coleta bloqueada - faltam 3585s` é
proteção normal (alguém disparou coleta manual 15s após o boot; o cooldown
de 1h bloqueou — não é erro, e o cooldown zera a cada redeploy).

**Consequência se ficar assim:** o ciclo automático de 3h falha na etapa 01
(coletor indisponível), nenhum PDF novo é gerado, e os links do Google News
param de ser resolvidos. Os PDFs/news.json antigos continuam servidos (não
há perda de dados). Enquanto isso, a rota `/` da API mostra o painel de
diagnóstico vermelho listando os 2 arquivos culpados.

### Defeito encontrado no pacote em 09/nov — feeds_collector.py (CORRIGIDO)

Na revisão de véspera do deploy, encontramos um defeito NO ARQUIVO DO
PRÓPRIO PACOTE (era meu, de uma edição anterior): a função interna
`_parse_date_string` ficou indentada 4 espaços demais, logo após o
`return None` de `parse_rss_date`. Sintaxe legal (o Python aceita), então
passou pelos testes de compilação — mas a função virou **código morto
dentro de outra função**: não existia mais no nível do módulo.

**Efeito prático (silencioso e relevante para a queda de volume):** a
recuperação de data via BS4 (`_fetch_date_via_bs4`) falhava sempre com um
`NameError` engolido pelo try/except → artigos de RSS sem data parsável no
feed e sem `/AAAA/MM/DD/` na URL eram **descartados como "sem data"** em
TODO ciclo. Menos artigos de RSS direto — a fatia que deveria compensar
quando o Google News limita o IP.

Corrigido (função devolvida ao nível do módulo) e validado ponta-a-ponta
em 09/nov, rede neutra, MESMAS 47 fontes / janela 24h / keywords:

- Coleta: **36 artigos** → dedup: **27 no PDF** (9 duplicatas intra-ciclo);
- gnews = **24/27 artigos (89%)** — confirma a medição da seção abaixo;
  24/24 links resolvidos para o publisher final, 0 apontando para
  news.google.com;
- PDF: 42 links clicáveis, nenhum "UTC" no texto;
- `_parse_date_string` testada com ISO+offset BR, RFC 822, formato BR e
  extração de `<meta property="article:published_time">` — todas OK.

### Correção — 3 passos, na ordem

1. **Baixe o pacote NOVO** (este, reempacotado em 09/nov — o fix do
   `feeds_collector.py` só existe aqui).
2. No Replit, **Upload file de TODOS os `.py` da raiz + a pasta `workflow/`
   inteira, de uma vez** (enviar só os 2 quebrados recria o deploy misturado
   da atualização anterior). NUNCA copy/paste no editor — é o que corrompeu
   os 2 arquivos nas duas últimas tentativas.
3. Shell do Replit: `python3 -m py_compile app.py feeds_collector.py gnews_resolver.py && echo OK`
   → **Redeploy** → o boot deve imprimir `[self-check] N modulos .py
   integros` e o ciclo de startup coleta na hora (cooldown em memória zera).

Se a página `/` continuar mostrando o painel vermelho, o nome do arquivo
culpado estará lá — agora com o sistema dizendo exatamente o que falta.

| Arquivo | Ação nesta atualização |
| --- | --- |
| `feeds_collector.py` | **CORRIGIDO no pacote** — `_parse_date_string` de volta ao nível do módulo (BS4 de datas volta a funcionar) |
| `LEIA-ME-CORRECAO.md` | esta seção |
| Seu Replit | substituir TODOS os `.py` por UPLOAD (os 2 corrompidos continuam lá) |

---

## 08/nov (4ª) — Por que o volume caiu de 20-50 para 5-13 artigos

**Nada mudou no código, nas keywords ou nas fontes.** Prova: no mesmo dia,
com as MESMAS 47 fontes, mesmas keywords e mesma janela de 24h, rodando de
uma rede neutra: 36 artigos coletados, **27 no PDF**, 33/39 fontes OK.
(Nota 09/nov: a revisão seguinte encontrou UM defeito silencioso do próprio
pacote — a recuperação de datas via BS4 estava morta, reduzindo a fatia de
RSS direto; corrigido e documentado na seção 09/nov acima. Não altera a
conclusão principal desta seção: o fator dominante é o rate limit do Google
News sobre o IP de saída.)

**A causa é o Google News limitando o IP de saída do Replit (HTTP 429):**

- Medição real do sistema: **88% dos artigos de um ciclo saudável vêm das
  queries "via Google News"** (no ciclo de teste: 23 de 26). RSS direto
  contribui com poucas matérias.
- Quando o Google limita o IP compartilhado do Replit, as 7 queries gnews
  respondem 429 instantâneo → o ciclo colapsa para os poucos artigos de RSS
  direto: **3 a 13 artigos** — exatamente o que você viu (9, 6, 13).
- O padrão **oscila ciclo a ciclo** (43 → 9 → 6 → 21 → 13) — assinatura de
  rate limit em IP compartilhado, que melhora/piora conforme outros repls
  batem no Google com o mesmo IP. Não é perda de notícia: é a fonte sendo
  recusada.
- **Disparos manuais repetidos pioram** (cada um repete as 7 queries + as
  chamadas de resolução de links no news.google.com).

**Novas proteções no pacote:**

1. `feeds_collector.py` — quando o Google News responde 429, a query espera
   20s e tenta 1x de novo (resolve rajadas transitorias). Se persistir, o
   status da fonte fica explícito no log e na bolha do site:
   `HTTP 429 - Google News limitando este IP (rate limit; volta sozinho apos algumas horas)`.
2. `workflow/orchestrator.py` — o resumo final agora é honesto (antes
   mostrava o número BRUTO da etapa 01, não o do PDF):
   `Artigos coletados: 21 | apos dedup/ranqueamento (no PDF): 13`.
3. `app.py` — a resposta do botão de coleta também mostra os dois números.

**O que fazer:**

- Substitua o backend pelo pacote (quando resolver o deploy) — o log novo
  vai CONFIRMAR isso na próxima coleta: fontes gnews em 429/erro enquanto
  as RSS respondem.
- Prefira o ciclo automático de 3h; evite disparos manuais em sequência.
- Se o log mostrar 429 em massa por horas seguidas: aguarde (o Google
  libera sozinho) ou configure `PROXY_URL` nos Secrets — a coleta inteira
  passa a sair por um IP limpo que você controla.

| Arquivo | Ação nesta atualização |
| --- | --- |
| `feeds_collector.py` | alterado — retry em 429 do Google News (20s, 1x) + mensagem de status clara |
| `workflow/orchestrator.py` | alterado — resumo final separa coletados × pós-dedup (PDF) |
| `app.py` | alterado — mensagem do /collect com o número final |

---

## 08/nov/2026 (3ª) — Deploy não subia: "Exception in worker process" + healthcheck 500 em loop

**O que o log mostrou** (17:37 UTC do container = 14:37 de Brasília):

```
[ERROR] Exception in worker process
File ".../artifacts/api-server/backend/app.py", line 32, in <module>
from feeds_collector import load_session
File "<frozen importlib._bootstrap>", line 1387, in _gcd_import
```

**Causa: deploy MISTURADO.** O `app.py` em execução era a versão ANTIGA
(o import do `feeds_collector` estava na linha 32; no app.py novo ele está na
linha 48, depois do bloco de fuso `TZ=America/Sao_Paulo`). Com arquivos
antigos + novos convivendo, algum módulo do chain de import não existe ou não
compila no servidor (ex.: o `feeds_collector.py` NOVO importa `http_client.py` —
se só ele foi enviado, o boot explode exatamente assim). Um único arquivo
assim derruba o worker do gunicorn inteiro: healthcheck 500 em loop, site fora
do ar, e o traceback truncado não diz qual arquivo é.

**Correção estrutural (definitiva) — boot resiliente**: o `app.py` agora captura
a falha de QUALQUER módulo nucleo no boot. O worker NÃO crasha mais:

- `/healthz` responde **200** sempre (acaba o loop de healthcheck 500);
- a **página inicial da API** (`/`) mostra um painel de diagnóstico com cada
  arquivo culpado e a correção exata, por exemplo:
  - `ARQUIVO DO PROJETO AUSENTE: http_client.py -> o deploy esta parcial/misturado...`
  - `ARQUIVO CORROMPIDO (sintaxe/indentacao, linha 2: unexpected indent) -> recopie por UPLOAD`
  - `DEPENDENCIA AUSENTE: feedparser -> rode no Shell: pip install feedparser`
- o log de boot imprime `[boot] modulo 'X' falhou ao importar: <correção>`;
- coleta manual (`/collect`), news.json e PDFs respondem 503 com mensagem
  clara enquanto o modo degradado durar — nada de crash misterioso.

Testado simulando os dois cenários reais: (a) pacote parcial sem
`http_client.py` → API sobe, `/` aponta o arquivo ausente; (b) arquivo com
indentação quebrada de copy/paste → `/` mostra "ARQUIVO CORROMPIDO ... linha 2:
unexpected indent" (o mesmo erro do seu log de 08/nov de manhã).

**Como aplicar — leia com atenção, é aqui que o seu deploy quebrou:**

1. Envie por **Upload file** TODOS os `.py` da tabela abaixo DE UMA VEZ
   (não substitua só alguns — deploy misturado é a causa deste crash):
   `app.py`, `config.py`, `feeds_collector.py`, `gnews_resolver.py`,
   `briefing_generator.py`, `publisher.py`, `maintenance.py`, `scheduler.py`,
   `http_client.py`, `workflow/` (pasta inteira).
2. Confirme no Shell: `python3 -m py_compile app.py feeds_collector.py gnews_resolver.py http_client.py && echo OK`
3. **Redeploy**. Se algo ainda estiver errado, agora o site ABRE e mostra
   exatamente o que falta — em vez de ficar em healthcheck 500.

**Sobre "as notícias não vieram" (ciclo das 16:08, 9 artigos; e o das
16:54, 6 artigos):** coleta de 12s é rápida demais para 39 fontes — as
falhas foram instantâneas em massa (rate limit/bloqueio do IP de saída), não
falta de notícia. Dois avisos: (1) disparos manuais repetidos em sequência
aumentam o bloqueio temporário das fontes — prefira esperar o ciclo
automático de 3h; (2) agora o log da Etapa 01 imprime o detalhe por fonte
quando o ciclo vem baixo, então o próximo ciclo "vazio" já vai dizer qual
fonte falhou e por quê:

```
[01] fonte com erro: SecurityWeek -> HTTP 403
[01] fontes sem itens novos na janela (24h): ['CaveiraTech (via Google News)']
[01] coleta baixa (6 artigos) - detalhe por fonte: CISO Advisor=error, ...,
     SecurityWeek=error, ... | gnews: BleepingComputer=no_results, ...
```

| Arquivo | Ação nesta atualização |
| --- | --- |
| `app.py` | **alterado** — boot resiliente: diagnóstico na `/`, healthz 200, módulo quebrado não derruba mais o worker |
| `briefing_generator.py` | alterado — rodapé/subtítulo do PDF em Brasília (era "no ciclo ... UTC") |
| `workflow/01_collect.py` | alterado — detalhe por fonte no log quando a coleta vem baixa |

---

## 08/nov/2026 — "resolucao de links falhou ... unexpected indent (gnews_resolver.py, line 2)"

**Causa: o `gnews_resolver.py` está corrompido no seu Replit.**
`unexpected indent` é erro de SINTAXE do Python — alguma linha do arquivo
tem espaços à esquerda demais (assinatura clássica de copy/paste no editor,
que às vezes indenta o texto colado). O arquivo deste pacote NÃO está assim:
os 15 `.py` foram reconferidos e compilam 100% limpos (a linha 2 do
`gnews_resolver.py` é a abertura da docstring, sem espaço nenhum).

Efeito prático: o import do resolver falha e a resolução INTEIRA do ciclo é
abortada (o coletor protege o ciclo com try/except e segue em frente) —
por isso **todos os artigos das fontes "via Google News" ficam com o link de
redirecionamento do Google** em vez da URL da matéria original, no site e no
PDF. As fontes RSS não são afetadas (sempre tiveram link direto).

Como corrigir:

1. No Replit, SUBA o arquivo (`Upload file`) `gnews_resolver.py` deste
   pacote por cima do existente. **Prefira upload a copiar/colar o texto no
   editor — é o copy/paste que corrompe.**
2. Confirme no Shell do Replit:
   `python3 -m py_compile gnews_resolver.py && echo OK` (deve imprimir OK).
3. Faça redeploy. No boot deve aparecer `[self-check] N modulos .py
   integros` e, no primeiro ciclo:
   `[gnews-resolver] resolvidos: N/N links apontam agora para a fonte final`.

Reforços incluídos nesta atualização do pacote:

- `app.py` — **self-check de integridade no boot**: verifica a sintaxe de
  todos os `.py` do projeto no primeiro segundo de vida e grita no log
  (`[self-check] ARQUIVO PYTHON CORROMPIDO: <arquivo> -> linha N: ...`) se
  qualquer um estiver quebrado. Antes, esse tipo de corrupção só aparecia
  minutos depois, como um warning no meio do ciclo — fácil de passar batido.
- `feeds_collector.py` — quando a resolução falha por sintaxe/indentação, o
  warning agora aponta a causa e a correção.
- Teste ponta-a-ponta re-executado em 08/nov: 8/8 links gnews reais
  resolvidos para o publisher (CyberSecBrazil, IT Forum, TI Inside etc.);
  PDF gerado com 10 links clicáveis — nenhum apontando para
  news.google.com.

| Arquivo | Ação nesta atualização |
| --- | --- |
| `gnews_resolver.py` | **Subir de novo no Replit** (o do pacote está íntegro) |
| `app.py` | alterado (self-check de integridade no boot) |
| `feeds_collector.py` | alterado (mensagem de erro mais explicativa) |

---

## 08/nov/2026 (2ª) — Fuso horário de Brasília + ciclo com poucos artigos

### 1. Hora errada no PDF/sessão/log — CORRIGIDO

O container do Replit roda em **UTC** e o sistema exibia essa hora crua:
um ciclo executado às 13:08 de Brasília gerava session_id e nome de PDF
`20261108_160832` (3h no futuro). O modelo de DADOS do projeto sempre foi
UTC interno (janela de 24h, dedup, published dos artigos), então a correção
fica só na camada de NOMES e EXIBIÇÃO:

| O que | Antes (UTC) | Agora (Brasília) |
| --- | --- | --- |
| session_id / nome do PDF | `20261108_160832` | `20261108_130832` |
| Timestamps do log | `16:08:32,997` | `13:08:32,997` |
| Data do artigo no PDF | `08/11/2026 16:08 UTC` | `08/11/2026 13:08 (Brasilia)` |
| Chips de sessão do site | hora UTC | hora de Brasília |
| `generated_at` no news.json | ISO sem offset | ISO com `-03:00` |

Como: `config.py` ganhou `TZ_BRASILIA` (offset fixo -3; o Brasil não tem
horário de verão desde 2019) e `now_local()`; `app.py` e `start.sh` FORÇAM
`TZ=America/Sao_Paulo` no processo (por cima do `TZ=UTC` que o container
pode trazer pré-definido — para outro fuso, defina a env `APP_TZ`). A
janela de 24h e todas as comparações internas continuam em UTC: nenhum
comportamento de coleta muda.

Validado em teste real: container simulado em UTC às 16:20 → log do
processo em 13:20; PDF gerado para `published=16:08 UTC` mostra
`08/11/2026 13:08 (Brasilia)`; chip do site `8NOV 13:08`.

### 2. Ciclo das 16:08 veio com só 9 artigos (e em 12,2s)

**12,2s é rápido demais para 39 fontes** — ciclo saudável leva de 1 a 6
min (o das 00:24 levou 341s e trouxe 43 artigos do MESMO período de 24h).
O padrão "rápido + poucos artigos" indica falhas INSTANTÂNEAS em massa:
tipicamente respostas 4xx (rate limit/bloqueio do IP de egress do Replit)
ou rede cortando conexão na hora — não falta de notícia nova.

Para a causa ficar visível no próprio log, a coleta agora imprime no fim
da Etapa 01:

```
[coleta] fontes consultadas: 39 | ok: N | sem itens novos: M | com erro: K
```

Se `com erro` for alto, olhe a bolha de status do site (ou `feed_status`
na sessão): 429/403 em massa = IP de egress queimado de novo → configure
`PROXY_URL` nos Secrets (seção "Se ainda assim alguma fonte persistir")
ou mova a região do deploy. SSL EOF em massa = o problema de caminho de
saída de 07/11 voltou. Para análise, cole o INÍCIO da Etapa 01 (linhas
por fonte) — o trecho enviado só mostrou o fim do ciclo.

| Arquivo | Ação nesta atualização |
| --- | --- |
| `config.py` | alterado (TZ_BRASILIA + now_local) |
| `app.py` | alterado (TZ forçada no processo, antes do logging) |
| `start.sh` | alterado (export TZ) |
| `briefing_generator.py` | alterado (datas do artigo e do ciclo em Brasília) |
| `feeds_collector.py` | alterado (session_id em Brasília + resumo de fontes no log) |
| `publisher.py` | alterado (chips de sessão e generated_at em Brasília) |
| `scheduler.py` | alterado (last_run/next_run em Brasília) |
| `workflow/orchestrator.py` | alterado (workflow_id em Brasília) |

**Suba TODOS os 8 arquivos da tabela** (além do `gnews_resolver.py` da
seção anterior, se ainda não subiu).

---

## Diagnóstico (o que estava acontecendo)

No ciclo de 07/11 a Etapa 01 coletou só **11 artigos**, com **12 fontes em erro**:
todas as hospedadas no Google (feeds.feedburner.com, googleprojectzero.blogspot.com,
security.googleblog.com, news.google.com) e várias atrás de CDN (WIRED, SANS,
Olhar Digital, Tecnoblog, Security Affairs, Ars Technica, Hackread,
Convergência Digital) falhando com:

```
SSLError(5, '[SSL: UNEXPECTED_EOF_WHILE_READING]')
SSLEOFError(8, 'EOF occurred in violation of protocol')
Read timed out / Broken pipe / RemoteDisconnected
```

**Teste feito em 07/11:** os mesmos 13 endereços foram requisitados de uma rede
neutra com a MESMA stack (requests + os mesmos headers do backend). Resultado:
**12 de 13 responderam HTTP 200** (só o BleepingComputer dá 403 — Cloudflare,
por reputação de IP, já falhava também na sessão de 23/10 no zip).

Conclusão: **o código e os sites estão OK — o problema é o caminho de saída do
Replit** (IP egress compartilhado, com reputação ruim / middlebox cortando TLS
no meio do handshake). Entre 23/10 (96 artigos, 1 erro) e 07/11 algo mudou
nesse caminho (novo IP de saída, migração de região do deploy ou ajuste de
rede do Replit — foge do nosso controle).

## O que foi mudado

Nova camada `http_client.py`, usada por `feeds_collector` e `gnews_resolver`:

1. **TLS limitado a 1.2** — elimina patologias de TLS 1.3 em middleboxes
   (classe conhecida de SSLEOFError com urllib3 2.x). Todos os feeds suportam 1.2.
2. **3 tentativas com backoff exponencial (~2s, ~4s, ~8s) + jitter**, e
   **conexão NOVA a cada tentativa** (socket envenenado não recontamina a retry).
   Antes eram 2 tentativas em 1,5s na mesma conexão.
3. **Fallback final via curl_cffi impersonando Chrome 124** — stack TLS de
   browser, que atravessa middleboxes que cortam a do Python. Se o pacote não
   estiver instalado, apenas pula (log avisa).
4. **Timeout separado**: 10s para handshake (host morto falha rápido) e
   15s de leitura (era 10s total — o Ars Technica estourava leitura).
5. **`trust_env=False`** — a coleta não herda proxy do ambiente do host.
6. **Escape hatch `PROXY_URL`** — se o IP de saída do Replit estiver queimado
   de vez, defina a variável de ambiente `PROXY_URL`
   (`http://usuario:senha@host:porta`) nos Secrets do Replit e TODA a coleta
   (RSS, gnews e resolver) sai pelo seu proxy.

Outras mudanças:

- `config.py`: `FETCH_TIMEOUT` padrão 10→15s; novos `HTTP_RETRIES=3` e
  `PROXY_URL` (tudo configurável por env).
- `requirements.txt`: adicionado `curl-cffi>=0.7`.
- `config/feeds.yaml`: BleepingComputer (RSS direto) → `enabled: false`
  (403 Cloudflare no Replit desde out/2026; o espelho
  "BleepingComputer (via Google News)" já cobre a fonte).
- `gnews_resolver.py`: GET de params e POST batchexecute usam o transporte
  endurecido (era o que mais sofria — dezenas de chamadas ao Google por ciclo).
- Mensagem de status para SSL ficou mais clara no PDF do briefing:
  "TLS interrompido no caminho (apos retries + fallback)".

## Arquivos alterados

| Arquivo | Ação |
| --- | --- |
| `http_client.py` | **NOVO** — transporte HTTP endurecido |
| `feeds_collector.py` | alterado (V4 — fetch via http_client) |
| `gnews_resolver.py` | alterado (V3 — fetch via http_client) |
| `config.py` | alterado (FETCH_TIMEOUT 15, HTTP_RETRIES, PROXY_URL) |
| `requirements.txt` | alterado (+ curl-cffi) |
| `config/feeds.yaml` | alterado (BleepingComputer RSS off) |

Atenção: seu `feeds.yaml` no Replit pode ter edições mais novas que a cópia do
zip — se sim, replique nele apenas a mudança do BleepingComputer em vez de
sobrescrever o arquivo.

## Como aplicar no Replit

1. Substitua/suba os arquivos da tabela acima na raiz do backend.
2. `curl-cffi` será instalado no próximo build (requirements.txt). Se o deploy
   não reinstalar dependências automaticamente, rode no Shell do Replit:
   `pip install -r requirements.txt`
3. Reinicie o deploy e dispare um ciclo (ou aguarde o scheduler).
4. No log, o que esperar:
   - fontes que antes morriam em SSLEOFError passam a tentar 3x com conexão
     nova e, persistindo, via curl_cffi (Chrome);
   - `[http] fallback curl_cffi (Chrome) usada para <host> após 3 falhas TLS`
     indica que a defesa entrou em ação;
   - a etapa 01 pode ficar ~1-2 min mais longa nos ciclos ruins (backoff),
     trocando erros por artigos.

## Se ainda assim alguma fonte persistir em erro

- **403 (Cloudflare)**: é reputação de IP — não é código. Já cobrimos
  BleepingComputer via Google News; as demais ficam para o próximo ciclo.
- **SSL persistente em muitas fontes ao mesmo tempo**: o egress do Replit
  piorou de novo. Duas saídas: (a) mover o backend para outra região/deploy no
  Replit; (b) definir `PROXY_URL` nos Secrets apontando para um proxy seu
  (VM barata em qualquer cloud resolve).

## Links finais da matéria no site e no PDF (07/nov/2026)

**Sim, é possível — e o sistema já foi desenhado para isso.** O
`gnews_resolver.py` existe exatamente para trocar o link do Google News
pela URL final do publisher, e o PDF + o site sempre mostram o campo
`link` do artigo (no PDF o endereço aparece em texto E é clicável).

Prova nas sessões de outubro do próprio zip: 0 links do Google News
(56, 62 e 57 links resolvidos por ciclo). O que estava acontecendo agora:
com o TLS do Replit quebrado, o resolver era a etapa mais atingida — são
dezenas de chamadas ao `news.google.com` por ciclo (1 GET + 1 POST por
artigo) — e, sem resolução, o artigo ficava com o link intermediário do
Google no site e no PDF.

Reforços aplicados nesta entrega:

1. **Cache persistente** (`data/gnews_cache.json`): um link resolvido UMA
   vez fica resolvido para sempre — mesmo após redeploy/restart do Replit,
   que zerava o cache em memória. Como a janela é 24h, o mesmo artigo
   repete por até 8 ciclos: resolvido no 1º, os seguintes custam zero rede.
2. **Transporte endurecido** (já descrito acima): TLS 1.2, 3 tentativas
   com conexão nova, fallback curl_cffi nas chamadas ao Google.
3. **Visibilidade**: se algum artigo ficar sem resolução, o log do ciclo
   avisa: `[gnews] N artigo(s) seguem com link do Google News (...)`.

Verificação em teste real (07/nov): ciclo completo com 34 fontes OK →
**0 links do Google News** nos artigos; PDF gerado com 63 links clicáveis,
nenhum apontando para news.google.com; segunda passada resolveu tudo em
0.0s usando só o cache persistente.

## Fontes adicionadas (07/nov/2026)

A pedido da equipe, duas fontes nacionais entraram no `config/feeds.yaml`:

| Fonte | Tipo | Endereço | Observação |
| --- | --- | --- | --- |
| CyberSecBrazil | rss | `https://www.cybersecbrazil.com.br/blog-feed.xml` | é o novo domínio do "Cyber Security Brazil" (entrada antiga segue desativada, com nota apontando para cá). Feed validado: 20 matérias, atualizado no dia. |
| CaveiraTech (via Google News) | gnews | query `site:caveiratech.com` | o site **não expõe RSS** (só sitemap de 8.5k URLs) e não declara plataforma; cobertura via Google News no mesmo padrão do BleepingComputer. Testado: itens entram assim que publicados (o filtro de janela de 24h descarta as páginas estáticas antigas que o GNews mistura no resultado). |

No teste de ciclo com as duas fontes ativas: 34 fontes OK e 39 artigos únicos,
com o CyberSecBrazil contribuindo 3 matérias (links diretos para o site, sem
intermediário). matérias de "Black Friday" continuam sendo bloqueadas pela
blocklist do `keywords.yaml`, exceto quando contêm termo de override
(comportamento existente do filtro, mantido).

## Testes já executados (07/nov)

- 13 feeds problemáticos testados de rede neutra: 12× HTTP 200 (só
  BleepingComputer 403 — bloqueio de IP, não de fingerprint).
- Simulação de falha total do requests → fallback curl_cffi assumiu e
  retornou HTTP 200 com o feed íntegro.
- Coleta completa `collect_all()` com o código novo: 33 fontes OK,
  34/35 links gnews resolvidos, 0 falha de TLS (as únicas 3 mensagens de
  403 foram do IP do ambiente de teste — essas mesmas fontes funcionam no
  seu Replit desde outubro).
- `app.py` importa e sobe com as assinaturas preservadas
  (`collect_all`, `load_sources`, `resolve_links` inalteradas).
