# -*- coding: utf-8 -*-
"""
4root News System - API (Flask no Replit ou servidor proprio)
=============================================================
Arquitetura Opcao B (Front no Pages + API no Replit):

    GitHub Pages (news.4root.com.br)
        serve index.html + static/ (100% estatico, sem backend).
        O JS busca os dados em NEWS_API_BASE + /data/news.json.

    API Flask (Replit)
        python3 app.py -> scheduler interno coleta a cada 3h
        (coleta -> dedup/rank -> PDF) e serve:
            /data/news.json  dados do ciclo (CORS liberado)
            /export/<pdf>    PDFs de cada ciclo
            POST /collect    dispara coleta manual (cooldown 1h)

    Flask local (desenvolvimento)
        a mesma index.html e servida na mesma origem (NEWS_API_BASE
        vazio) - nada muda para o desenvolvedor.

Configuracao 100% em arquivos: config/feeds.yaml e config/keywords.yaml.
"""
import os
import logging
import time as _time

# Fuso do PROCESSO: America/Sao_Paulo. O container roda em UTC (e pode
# vir com TZ=UTC pre-definido no ambiente) e, sem isso, os timestamps do
# LOG nasciam em UTC (ex.: ciclo das 13:08 de Brasilia aparecia como
# 16:08). FORCA America/Sao_Paulo a menos que APP_TZ diga o contrario.
# Afeta apenas o relogio APARENT do processo (logging/time.localtime/
# datetime.now() naive); os dados internos em UTC (timezone.utc) e a
# camada de exibicao now_local() (config.py) ficam inalterados.
# Precisa vir ANTES do basicConfig.
os.environ['TZ'] = os.environ.get('APP_TZ', 'America/Sao_Paulo')
try:
    _time.tzset()          # Linux/Replit
except AttributeError:     # Windows (dev local)
    pass

from flask import (Flask, render_template, jsonify, send_file,
                   send_from_directory, abort, request)

# ================================================================
# IMPORTS NUCLEO COM DIAGNOSTICO (boot resiliente)
# ----------------------------------------------------------------
# Antes: um unico arquivo corrompido (copy/paste no editor) ou ausente
# (upload parcial do pacote) derrubava o worker do gunicorn NA LINHA DO
# IMPORT - o deploy ficava em loop de "healthcheck 500" e o traceback
# truncado no log nao dizia qual arquivo era. Agora: a falha e CAPTURADA,
# LOGADA com a correcao exata, o worker SOBE e a pagina inicial da API
# mostra o diagnostico completo ate a correcao ser feita.
# ================================================================
import importlib

BOOT_ERRORS = []   # [(origem, mensagem legivel com correcao)]

_MODULOS_DO_PROJETO = {'config', 'http_client', 'gnews_resolver',
                       'feeds_collector', 'briefing_generator', 'publisher',
                       'maintenance', 'scheduler', 'workflow'}
_PACOTES = {'yaml': 'pyyaml', 'bs4': 'beautifulsoup4',
            'dateutil': 'python-dateutil', 'curl_cffi': 'curl-cffi',
            'PIL': 'pillow'}


def _fmt_boot_error(exc):
    """Converte a excecao de import em uma instrucao de correcao."""
    if isinstance(exc, (SyntaxError, IndentationError)):
        return (f"ARQUIVO CORROMPIDO (sintaxe/indentacao, linha "
                f"{exc.lineno}: {exc.msg}) -> recopie o arquivo do pacote "
                f"backend-corrigido.zip por UPLOAD (nunca copy/paste no "
                f"editor) e faca redeploy")
    if isinstance(exc, ModuleNotFoundError):
        mod = getattr(exc, 'name', '') or ''
        if mod.split('.')[0] in _MODULOS_DO_PROJETO:
            return (f"ARQUIVO DO PROJETO AUSENTE: {mod}.py -> o deploy esta "
                    f"parcial/misturado com versao antiga. Faca UPLOAD de "
                    f"TODOS os .py do pacote backend-corrigido.zip juntos "
                    f"(nao substitua apenas alguns) e faca redeploy")
        pkg = _PACOTES.get(mod.split('.')[0], mod.split('.')[0])
        return (f"DEPENDENCIA AUSENTE: {mod} -> rode no Shell do Replit: "
                f"pip install {pkg}")
    return f"{type(exc).__name__}: {exc}"


# ---- config primeiro (as constantes abaixo sao usadas pelo logging) ----
try:
    from config import (BASE_DIR, DATA_DIR, EXPORT_DIR, LOGS_DIR,
                        BRIEFING_ORG, PUBLIC_API_URL,
                        COLLECT_COOLDOWN_SECONDS, RETENTION_DAYS)
except Exception as _cfg_exc:  # noqa: BLE001 - boot continua em modo degradado
    BOOT_ERRORS.append(('config', _fmt_boot_error(_cfg_exc)))
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    DATA_DIR = os.path.join(BASE_DIR, 'data')
    EXPORT_DIR = os.path.join(BASE_DIR, 'export')
    LOGS_DIR = os.path.join(BASE_DIR, 'logs')
    BRIEFING_ORG = '4ROOT'
    PUBLIC_API_URL = ''
    COLLECT_COOLDOWN_SECONDS = 3600
    RETENTION_DAYS = 6
    for _d in (DATA_DIR, EXPORT_DIR, LOGS_DIR):
        os.makedirs(_d, exist_ok=True)

# Configuracao de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(os.path.join(LOGS_DIR, 'app.log'), encoding='utf-8')
    ]
)
logger = logging.getLogger(__name__)

if BOOT_ERRORS:
    for _origem, _msg in BOOT_ERRORS:
        logger.error(f"[boot] modulo '{_origem}' falhou ao importar: {_msg}")


def _core_module(name):
    """Importa um modulo nucleo; falha e logada e NAO derruba o boot."""
    try:
        return importlib.import_module(name)
    except Exception as exc:  # noqa: BLE001 - degraded: API sobe e diagnostica
        msg = _fmt_boot_error(exc)
        BOOT_ERRORS.append((name, msg))
        logger.error(f"[boot] modulo '{name}' falhou ao importar: {msg}")
        return None


feeds_collector = _core_module('feeds_collector')
gnews_resolver_mod = _core_module('gnews_resolver')   # lazy no coletor: checar aqui
briefing_generator = _core_module('briefing_generator')
publisher = _core_module('publisher')
workflow_orchestrator = _core_module('workflow.orchestrator')
maintenance_mod = _core_module('maintenance')
scheduler = _core_module('scheduler')


def _indisponivel(modulo):
    """Substituto que levanta erro claro quando o modulo nucleo falhou."""
    def _raise(*_a, **_k):
        raise RuntimeError(
            f"modulo '{modulo}' indisponivel no boot (deploy parcial/corrompido) "
            f"- a pagina inicial da API (/) lista o arquivo culpado e a correcao")
    return _raise


load_session = (feeds_collector.load_session if feeds_collector
                else _indisponivel('feeds_collector'))
generate_news_digest_pdf = (briefing_generator.generate_news_digest_pdf
                            if briefing_generator
                            else _indisponivel('briefing_generator'))
format_date_ddmmaaaa = (briefing_generator.format_date_ddmmaaaa
                        if briefing_generator
                        else (lambda *a, **k: '---'))
build_public_json = (publisher.build_public_json if publisher
                     else _indisponivel('publisher'))
run_full_pipeline = (workflow_orchestrator.run_full_pipeline
                     if workflow_orchestrator
                     else _indisponivel('workflow.orchestrator'))
cooldown_retry_after = (workflow_orchestrator.cooldown_retry_after
                        if workflow_orchestrator else (lambda: 0))
cleanup_old_artifacts = (maintenance_mod.cleanup_old_artifacts
                         if maintenance_mod else _indisponivel('maintenance'))


# ============ SELF-CHECK DE INTEGRIDADE (boot) ============
# O editor do Replit corrompe arquivos em copy/paste (indentacao quebrada)
# sem que o deploy falhe: o modulo quebrado so explode quando importado em
# runtime - e imports lazy dentro de try/except (ex. gnews_resolver em
# feeds_collector) degradam EM SILENCIO (links do Google News permanecem).
# Este check torna o problema visivel no primeiro segundo do boot.

def _self_check_syntax():
    """Verifica a SINTAXE de todos os .py do projeto no boot (em memoria,
    sem escrever .pyc). Pega corruptelas de copy/paste no editor do Replit
    (indentacao quebrada) que so explodiriam em runtime - e imports lazy
    dentro de try/except (ex. gnews_resolver em feeds_collector) falham
    em silencio, degradando o sistema (links do Google News permanecem)."""
    skip_dirs = {'__pycache__', 'node_modules', 'venv', '.venv', 'static',
                 'templates', 'data', 'logs', 'export'}
    broken, checked = [], 0
    for root, dirs, files in os.walk(BASE_DIR):
        dirs[:] = [d for d in dirs if d not in skip_dirs
                   and not d.startswith('.')]
        for fn in files:
            if not fn.endswith('.py'):
                continue
            path = os.path.join(root, fn)
            rel = os.path.relpath(path, BASE_DIR)
            checked += 1
            try:
                with open(path, 'rb') as fh:
                    src = fh.read()
                compile(src, path, 'exec')
            except SyntaxError as exc:
                broken.append((rel, f"linha {exc.lineno}: {exc.msg}"))
            except Exception as exc:  # noqa: BLE001 - qualquer falha importa
                first_line = str(exc).splitlines()[0] if str(exc) else repr(exc)
                broken.append((rel, first_line))
    if broken:
        for rel, err in broken:
            logger.error(
                f"[self-check] ARQUIVO PYTHON CORROMPIDO: {rel} -> {err} | "
                f"recopie este arquivo do pacote backend-corrigido.zip "
                f"(prefira UPLOAD do arquivo a copy/paste no editor) "
                f"e faca redeploy")
        logger.error(
            f"[self-check] {len(broken)}/{checked} modulos corrompidos - "
            f"funcionalidades vao degradar em runtime (ex. links do "
            f"Google News deixam de ser resolvidos)")
    else:
        logger.info(f"[self-check] {checked} modulos .py integros")


_self_check_syntax()

if BOOT_ERRORS:
    logger.error(f"[boot] {len(BOOT_ERRORS)} modulo(s) nucleo indisponivel(is) "
                 f"- a API sobe em modo degradado e a rota / mostra o "
                 f"diagnostico; corrija e faca redeploy")

app = Flask(__name__)
# estaticos sempre revalidados (ETag/304): nada de CSS/JS antigo em cache
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0


# ============ CORS (frontend estatico no GitHub Pages) ============

ALLOWED_ORIGINS = {'https://news.4root.com.br'}


@app.after_request
def add_cors(resp):
    """Permite que o site publicado leia a API sem liberar CORS para qualquer site."""
    origin = request.headers.get('Origin')
    if origin in ALLOWED_ORIGINS:
        resp.headers['Access-Control-Allow-Origin'] = origin
        resp.headers['Vary'] = 'Origin'
    resp.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
    resp.headers['Access-Control-Allow-Headers'] = 'Content-Type'
    resp.headers['Access-Control-Max-Age'] = '600'
    return resp


# ============ CONTEXTO GLOBAL (bolha de status) ============

def _collect_feed_status(session):
    """Une o status de todas as fontes do ciclo (RSS + gnews)."""
    if not session:
        return []
    status = session.get('feed_status', []) + session.get('gnews_status', [])
    return sorted(status, key=lambda s: s.get('name', '').lower())


@app.context_processor
def inject_bot_status():
    """Injeta o status dos feeds da ultima coleta na bolha (todas as paginas)."""
    try:
        session = load_session()
    except Exception:  # noqa: BLE001
        session = None
    feed_status = _collect_feed_status(session)
    total = len(feed_status)
    ok = len([f for f in feed_status if f.get('status') == 'ok'])
    err = len([f for f in feed_status if f.get('status') not in ('ok', 'no_results')])
    try:
        sched_enabled = scheduler.status().get('enabled', False)
        scheduler_status = 'ativa' if sched_enabled else 'manual'
    except Exception:  # noqa: BLE001
        scheduler_status = '-'
    summary = f'{ok}/{total} fontes respondendo' if total else 'aguardando primeiro ciclo'
    return {
        'bot_feed_status': feed_status,
        'bot_feed_total': total,
        'bot_feed_ok': ok,
        'bot_feed_err': err,
        'bot_feed_summary': summary,
        'scheduler_status': scheduler_status,
    }


# ============ ROTAS PRINCIPAIS ============

_API_STATUS_HTML = """<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/png" href="/static/favicon.png">
<title>4root // news — API</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { background:#0a0a0a; color:#eaeaea; min-height:100vh; display:flex;
         align-items:center; justify-content:center; padding:24px;
         font-family:'Sora',system-ui,-apple-system,sans-serif; }
  .card { max-width:640px; width:100%; border:1px solid #232323; border-radius:14px;
          background:#111; padding:32px; }
  .logo { font-size:26px; letter-spacing:.5px; }
  .logo b { color:#c7f000; }
  .logo small { color:#8a8a8a; font-size:13px; }
  .badge { display:inline-block; margin:14px 0 4px; padding:4px 12px; border-radius:999px;
           background:rgba(199,240,0,.12); color:#c7f000; font-size:13px; }
  p.hint { color:#8a8a8a; font-size:14px; line-height:1.6; margin-top:10px; }
  code { font-family:ui-monospace,Menlo,monospace; font-size:13px; color:#c7f000;
         background:rgba(199,240,0,.07); padding:2px 6px; border-radius:5px; word-break:break-all; }
  .row { margin-top:14px; padding:12px 14px; border:1px solid #1e1e1e; border-radius:10px;
         font-size:14px; display:flex; gap:10px; align-items:baseline; }
  .m { color:#8a8a8a; font-size:11px; min-width:44px; font-family:ui-monospace,monospace; }
  .url-box { margin-top:18px; padding:14px; border:1px dashed #2e2e2e; border-radius:10px; }
  .url-box .lbl { font-size:12px; color:#8a8a8a; margin-bottom:6px; }
  .url-box code { font-size:14px; }
</style>
</head>
<body>
  <div class="card">
    <div class="logo">#_4root <b>//</b> news <small>&mdash; API</small></div>
    <span class="badge">&#9679; API no ar</span>
    <p class="hint">Frontend 100% est&aacute;tico no GitHub Pages; esta API alimenta
    o site via CORS. Configur&aacute;vel pelo frontend em
    <code>window.NEWS_API_BASE</code> (index.html).</p>
    <div class="row"><span class="m">GET</span><span><code>__API__/data/news.json</code> &mdash; dados do ciclo</span></div>
    <div class="row"><span class="m">GET</span><span><code>/export/&lt;arquivo.pdf&gt;</code> &mdash; PDFs dos ciclos</span></div>
    <div class="row"><span class="m">POST</span><span><code>/collect</code> &mdash; coleta manual (cooldown 1h)</span></div>
    <div class="url-box">
      <div class="lbl">Use esta URL no NEWS_API_BASE do frontend (Pages):</div>
      <code>__API__</code>
    </div>
  </div>
</body>
</html>"""


def _api_status_page():
    """Pagina de status da API (pacote Replit sem index.html).

    Mostra a URL publica detectada (request.url_root) para o usuario
    copiar no NEWS_API_BASE do frontend antes de publicar no Pages.
    """
    root = _public_api_base()
    html = (_API_STATUS_HTML.replace('__API__', root))
    return html


def _public_api_base():
    """Return the public Replit host when available, with an explicit override."""
    if PUBLIC_API_URL:
        return PUBLIC_API_URL.rstrip('/')

    domains = [domain.strip() for domain in
               os.environ.get('REPLIT_DOMAINS', '').split(',')
               if domain.strip()]
    if domains:
        domain = domains[0].removeprefix('https://').removeprefix('http://')
        return f'https://{domain.rstrip("/")}'

    return request.url_root.rstrip('/')


@app.route('/')
def index():
    """Pagina principal estatica (a mesma publicada no GitHub Pages).

    Os dados (artigos, ciclos, bolha de feeds) chegam ao frontend pela
    rota /data/news.json - identica ao data/news.json do Pages.

    No pacote Replit (API-only) a index.html nao existe: a raiz mostra
    a pagina de status da API com a URL publica a configurar no frontend.
    Para servir o site na mesma origem (modo dev), basta copiar a
    index.html + static/ do pacote frontend para a raiz do projeto.

    Se algum modulo nucleo falhou no boot (deploy parcial/corrompido), a
    raiz mostra o DIAGNOSTICO com o arquivo culpado e a correcao - a API
    nunca mais fica em loop de healthcheck 500 sem explicacao.
    """
    if BOOT_ERRORS:
        return _boot_diagnosis_page()
    if os.path.exists(os.path.join(BASE_DIR, 'index.html')):
        return send_from_directory(BASE_DIR, 'index.html')
    return _api_status_page()


_BOOT_DIAG_HTML = """<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>4root // news — diagnóstico de boot</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { background:#0a0a0a; color:#eaeaea; min-height:100vh; padding:32px 16px;
         font-family:'Sora',system-ui,-apple-system,sans-serif; }
  .card { max-width:760px; margin:0 auto; border:1px solid #3a1e1e; border-radius:14px;
          background:#111; padding:32px; }
  .logo { font-size:24px; letter-spacing:.5px; }
  .logo b { color:#c7f000; }
  .badge { display:inline-block; margin:14px 0 6px; padding:4px 12px; border-radius:999px;
           background:rgba(255,80,80,.14); color:#ff6b6b; font-size:13px; }
  p.hint { color:#8a8a8a; font-size:14px; line-height:1.6; margin-top:8px; }
  .err { margin-top:14px; padding:14px 16px; border:1px solid #3a1e1e;
         border-left:4px solid #ff6b6b; border-radius:10px; background:#160d0d; }
  .err .mod { font-family:ui-monospace,Menlo,monospace; font-size:14px; color:#ff9b9b;
              margin-bottom:6px; }
  .err .msg { font-size:14px; color:#eaeaea; line-height:1.55; word-break:break-word; }
  .fix { margin-top:20px; padding:16px; border:1px dashed #2e2e2e; border-radius:10px;
         font-size:14px; color:#c9c9c9; line-height:1.7; }
  .fix b { color:#c7f000; }
  code { font-family:ui-monospace,Menlo,monospace; font-size:13px; color:#c7f000; }
</style>
</head>
<body>
  <div class="card">
    <div class="logo">#_4root <b>//</b> news &mdash; API</div>
    <span class="badge">&#9679; boot em modo degradado &mdash; __N__ modulo(s) com problema</span>
    <p class="hint">O worker N&Atilde;O crashou: os m&oacute;dulos abaixo falharam ao importar
    (arquivo corrompido por copy/paste no editor ou upload parcial do pacote).
    Corrija, fa&ccedil;a <b>redeploy</b> e esta p&aacute;gina volta ao normal.</p>
    __ERROS__
    <div class="fix">
      <b>Corre&ccedil;&atilde;o padr&atilde;o (2 minutos):</b><br>
      1. Baixe o pacote <code>backend-corrigido.zip</code> completo;<br>
      2. No Replit, use <b>Upload file</b> para enviar TODOS os <code>.py</code> do
      pacote de uma vez (nunca copy/paste no editor &mdash; ele quebra a indenta&ccedil;&atilde;o);<br>
      3. Rode no Shell: <code>python3 -m py_compile &lt;arquivo&gt;.py &amp;&amp; echo OK</code>;<br>
      4. <b>Redeploy</b> e recarregue esta p&aacute;gina.
    </div>
  </div>
</body>
</html>"""


def _boot_diagnosis_page():
    """Diagnostico visivel dos modulos nucleo que falharam no boot."""
    blocos = []
    for origem, msg in BOOT_ERRORS:
        blocos.append(
            f'<div class="err"><div class="mod">&#10060; {origem}</div>'
            f'<div class="msg">{msg}</div></div>')
    html = _BOOT_DIAG_HTML.replace('__N__', str(len(BOOT_ERRORS)))
    html = html.replace('__ERROS__', '\n'.join(blocos))
    return html


@app.route('/healthz')
def healthz():
    """Health check usado pelo Replit e deployment.

    SEMPRE 200: mesmo com modulo nucleo quebrado, o worker sobe (modo
    degradado) para nao entrar em loop de healthcheck 500 - o diagnostico
    fica na rota / e no log de boot.
    """
    if BOOT_ERRORS:
        return jsonify({'status': 'degraded', 'service': '4root-news-api',
                        'boot_errors': [{'module': m, 'error': e}
                                        for m, e in BOOT_ERRORS]}), 200
    return jsonify({'status': 'ok', 'service': '4root-news-api'})


@app.route('/data/news.json')
def public_news_json():
    """JSON publico do frontend, montado on-the-fly a partir da ultima
    sessao. No Pages o frontend busca este endpoint na API (Replit);
    no Flask local vem pela mesma origem.

    Se o publisher nao carregou (boot degradado), serve o ultimo
    data/news.json estatico gerado - melhor que derrubar o site.
    """
    if publisher is None:
        fallback = os.path.join(DATA_DIR, 'news.json')
        if os.path.exists(fallback):
            return send_file(fallback, mimetype='application/json')
        return jsonify({'success': False,
                        'message': 'publisher indisponivel no boot - veja a '
                                   'pagina inicial da API para o diagnostico'}), 503
    payload = build_public_json(mode='replit')
    payload['api_base'] = _public_api_base()
    return jsonify(payload)


@app.route('/export/<path:filename>')
def export_file(filename):
    """PDF de um ciclo (links estaticos export/<arquivo>.pdf da interface)."""
    return send_from_directory(EXPORT_DIR, filename, as_attachment=True)


@app.route('/collect', methods=['POST', 'OPTIONS'])
def collect():
    """Acao unica: executa o pipeline completo (coleta -> dedup/rank -> PDF).

    Cooldown de COLLECT_COOLDOWN_SECONDS (padrao: 3600s / 1 hora):
    o disparo so e aceito se ja tiver passado 1h da ULTIMA coleta de
    qualquer origem (botao, scheduler ou CLI). Antes disso, 429 com
    retry_after para o contador do frontend.
    """
    if request.method == 'OPTIONS':  # preflight CORS
        return ('', 204)

    if workflow_orchestrator is None:
        logger.error("[collect] bloqueada - workflow.orchestrator indisponivel no boot")
        return jsonify({'success': False,
                        'message': 'pipeline indisponivel no boot (deploy '
                                   'parcial/corrompido) - a pagina inicial da '
                                   'API lista o arquivo culpado e a correcao'}), 503

    retry = cooldown_retry_after()
    if retry > 0:
        logger.warning(f"[cooldown] Coleta bloqueada - faltam {retry}s "
                       f"(limite: {COLLECT_COOLDOWN_SECONDS}s)")
        return jsonify({
            'success': False,
            'rate_limited': True,
            'retry_after': retry,
            'message': (f'Ultima coleta ha menos de 1h - aguarde '
                        f'{retry // 60} min para coletar novamente.'),
        }), 429

    logger.info("Iniciando pipeline completo (coleta = workflow)...")
    try:
        result = run_full_pipeline()
        feed_errors = result.get('feed_errors', [])
        # o numero que importa e o FINAL (apos dedup/ranqueamento) - o
        # que fica no PDF; total_collected e o bruto da etapa 01
        total_final = (len(result.get('articles', []))
                       or result.get('total_collected', 0))
        return jsonify({
            'success': result['success'],
            'message': (f"Pipeline concluido: {total_final} artigos "
                        f"(de {result.get('total_collected', 0)} coletados), "
                        f"PDF {'gerado' if result.get('export_path') else 'nao gerado'}"),
            'total_articles': total_final,
            'export_path': result.get('export_path', ''),
            'session_id': (result.get('session_data') or {}).get('session_id', ''),
            'pdf_file': (result.get('session_data') or {}).get('pdf_name', ''),
            'feed_errors': feed_errors,
            'step_results': result.get('step_results', []),
            'errors': result.get('errors', []),
        })
    except Exception as exc:
        logger.error(f"Erro no pipeline: {exc}", exc_info=True)
        return jsonify({'success': False, 'message': str(exc)}), 500


# ============ DOWNLOAD DE PDF (rotas classicas) ============

def _send_pdf_for_session(session):
    """Localiza (ou gera) o PDF de uma sessao e envia como download."""
    pdf_file = session.get('pdf_file', '')
    pdf_path = os.path.join(EXPORT_DIR, pdf_file) if pdf_file else ''
    if pdf_file and os.path.exists(pdf_path):
        return send_file(pdf_path, as_attachment=True,
                         download_name=pdf_file)

    # fallback: gera na hora a partir dos artigos da sessao
    if session.get('articles'):
        session_id = session.get('session_id', 'latest')
        date_str = format_date_ddmmaaaa()
        filename = f"BRIEFING - {BRIEFING_ORG} - {date_str} - {session_id}.pdf"
        generated = generate_news_digest_pdf(session, filename)
        if generated:
            return send_file(generated, as_attachment=True,
                             download_name=filename)

    abort(404)


@app.route('/session/<session_id>/pdf')
def session_pdf(session_id):
    """Baixa o PDF do ciclo (session-chip da interface)."""
    try:
        session = load_session(session_id)
    except RuntimeError:
        abort(503)
    if not session:
        abort(404)
    return _send_pdf_for_session(session)


@app.route('/export/pdf')
def export_pdf():
    """Baixa o PDF da sessao mais recente (botao de export da interface)."""
    try:
        session = load_session()
    except RuntimeError:
        abort(503)
    if not session:
        abort(404)
    return _send_pdf_for_session(session)


# ============ ERROR HANDLERS ============

@app.errorhandler(404)
def not_found(_e):
    return render_template('404.html'), 404


@app.errorhandler(500)
def server_error(_e):
    return render_template('500.html'), 500


def start_background_services():
    """Run startup cleanup and the periodic collector once per API process."""
    logger.info("Iniciando 4root News System (API)")
    if PUBLIC_API_URL:
        logger.info(f"Modo API publica (replit): {PUBLIC_API_URL}")
    else:
        logger.info("Modo API publica: base detectada por requisicao")
    # Retencao ao iniciar: mantem apenas RETENTION_DAYS dias de ciclos/PDFs
    if RETENTION_DAYS > 0:
        logger.info(f"Retencao ativa: mantendo {RETENTION_DAYS} dias de "
                    f"ciclos/relatorios (RETENTION_DAYS={RETENTION_DAYS})")
    try:
        cleanup_old_artifacts()
    except Exception as exc:  # noqa: BLE001
        logger.warning(f"Falha na limpeza inicial de retencao: {exc}")
    if scheduler is not None:
        scheduler.start_scheduler()
    else:
        logger.error("[boot] scheduler indisponivel - coleta automatica "
                     "desativada ate a correcao (veja rota /)")


if __name__ == '__main__':
    start_background_services()
    debug = os.environ.get('FLASK_DEBUG', '0') == '1'
    port = int(os.environ.get('PORT', '8000'))  # Replit injeta PORT
    # use_reloader=False: o reloader duplicaria a thread de coleta automatica
    app.run(host='0.0.0.0', port=port, debug=debug, use_reloader=False)
