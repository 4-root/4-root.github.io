# -*- coding: utf-8 -*-
"""
Configuracoes do 4root News System
==================================
Sistema de coleta, filtragem e briefing diario de ciberseguranca.

As fontes e as palavras-chave NAO ficam aqui: ficam em arquivos
editaveis dentro de config/ (config/feeds.yaml e config/keywords.yaml).
"""
import os
from datetime import datetime, timedelta, timezone

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
LOGS_DIR = os.path.join(BASE_DIR, 'logs')
EXPORT_DIR = os.path.join(BASE_DIR, 'export')
CONFIG_DIR = os.path.join(BASE_DIR, 'config')

# Arquivos de configuracao editaveis (fonte de verdade) - YAML
FEEDS_CONFIG_FILE = os.path.join(CONFIG_DIR, 'feeds.yaml')
KEYWORDS_CONFIG_FILE = os.path.join(CONFIG_DIR, 'keywords.yaml')

# Garantir diretorios existam
for d in [DATA_DIR, LOGS_DIR, EXPORT_DIR, CONFIG_DIR]:
    os.makedirs(d, exist_ok=True)

# ================================================================ fuso
# Fuso de EXIBICAO: America/Sao_Paulo (UTC-3). O Brasil nao tem horario
# de verao desde 2019 -> offset fixo, sem dependencia de tz database.
#
# Regra do projeto:
#   - DADOS internos (janela de 24h, dedup, published/collected_at dos
#     artigos) continuam 100% em UTC (timezone.utc);
#   - NOMES e EXIBICAO (session_id, nome do PDF, gerado_em, chips do
#     site, proximo ciclo) usam now_local() -> hora de Brasilia.
#
# O container do Replit roda em UTC; sem isso, o session_id e o nome do
# PDF nasciam 3h no futuro em relacao ao usuario (ex.: ciclo das 13:08
# de Brasilia era gravado como 16:08).
TZ_BRASILIA = timezone(timedelta(hours=-3))


def now_local():
    """Agora no fuso de Brasilia (APENAS para nomes/exibicao)."""
    return datetime.now(TZ_BRASILIA)


# Identificacao usada nos briefings (interface, nome de arquivo e PDF)
BRIEFING_ORG = os.environ.get('BRIEFING_ORG', '4ROOT')

# Janela padrao de tempo para noticias (horas)
# (pode ser sobrescrita por config/keywords.yaml -> window_hours)
NEWS_WINDOW_HOURS = 24

# ------------------------------------------------------------------
# Coleta paralela (pool unico para RSS + Google News)
# ------------------------------------------------------------------
COLLECT_WORKERS = int(os.environ.get('COLLECT_WORKERS', '16'))  # threads simultaneas
FETCH_TIMEOUT = int(os.environ.get('FETCH_TIMEOUT', '15'))      # timeout de LEITURA por fonte (s)
MAX_PER_FEED = 40           # limite de artigos por feed por ciclo
MAX_SUMMARY = 500           # tamanho maximo do resumo armazenado
BS4_DATE_CAP = int(os.environ.get('BS4_DATE_CAP', '5'))  # max buscas BS4 de data por fonte

# ------------------------------------------------------------------
# Transporte HTTP endurecido (http_client.py) - resolve os
# SSLEOFError/UNEXPECTED_EOF do egress do Replit:
#   - HTTP_RETRIES: tentativas por requisicao (backoff exponencial);
#   - PROXY_URL: opcional. Se o IP de saida do Replit estiver queimado,
#     defina um proxy seu (http://user:senha@host:porta) e TODA a
#     coleta (RSS, gnews e resolver) saira por ele.
# ------------------------------------------------------------------
HTTP_RETRIES = int(os.environ.get('HTTP_RETRIES', '3'))
PROXY_URL = os.environ.get('PROXY_URL', '').strip()

# ------------------------------------------------------------------
# Coleta automatica em background (scheduler interno da API)
# Ciclo padrao: a cada 3 horas (coleta + geracao de noticias/PDF).
# ------------------------------------------------------------------
AUTO_COLLECT_ENABLED = os.environ.get('AUTO_COLLECT_ENABLED', '1') == '1'
AUTO_COLLECT_INTERVAL_HOURS = float(os.environ.get('AUTO_COLLECT_INTERVAL_HOURS', '3'))
AUTO_COLLECT_ON_STARTUP = os.environ.get('AUTO_COLLECT_ON_STARTUP', '1') == '1'

# ------------------------------------------------------------------
# Cooldown da coleta manual (botao "executar workflow")
# O disparo so e aceito se ja tiver passado COOLDOWN desde a ULTIMA
# coleta de qualquer origem (manual, botao ou scheduler).
# ------------------------------------------------------------------
COLLECT_COOLDOWN_SECONDS = int(
    os.environ.get('COLLECT_COOLDOWN_SECONDS', '3600'))  # 1 hora

# ------------------------------------------------------------------
# URL publica da API (modo Replit/servidor proprio).
# Deixe vazio quando o site e servido pela propria API (mesma origem).
# No GitHub Pages, o frontend busca dados aqui -> o JSON volta com
# api_base preenchido e o botao/PDFs apontam para a API.
# ------------------------------------------------------------------
PUBLIC_API_URL = os.environ.get('PUBLIC_API_URL', '').rstrip('/')

# ------------------------------------------------------------------
# Retencao: ciclos/relatorios mantidos por N dias (0 = manter tudo)
# sessions, workflow logs e PDFs mais antigos que RETENTION_DAYS sao
# apagados ao fim de cada ciclo e na inicializacao.
# ------------------------------------------------------------------
RETENTION_DAYS = int(os.environ.get('RETENTION_DAYS', '6'))

# Caminho das fontes oficiais usadas no PDF (logo + textos)
STATIC_DIR = os.path.join(BASE_DIR, 'static')
FONT_QB_ONE = os.path.join(STATIC_DIR, 'fonts', 'qb-one-semi-bold.ttf')
FONT_SORA = os.path.join(STATIC_DIR, 'fonts', 'Sora.ttf')

# Meses em portugues para datas
MESES_PT = {
    1: 'JAN', 2: 'FEV', 3: 'MAR', 4: 'ABR', 5: 'MAI', 6: 'JUN',
    7: 'JUL', 8: 'AGO', 9: 'SET', 10: 'OUT', 11: 'NOV', 12: 'DEZ'
}
