# -*- coding: utf-8 -*-
"""
Workflow Etapa 01 - Coleta de Feeds (paralela)
Coleta artigos de todas as fontes RSS, web e GNews configuradas.
"""
import sys
import os
import logging

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from feeds_collector import collect_all

logger = logging.getLogger('workflow.01')


def run(context):
    """Executa a coleta de feeds e atualiza o contexto do workflow."""
    logger.info("[01] Iniciando coleta paralela de feeds RSS e GNews...")

    session_data = collect_all()

    context['session_data'] = session_data
    context['articles'] = session_data.get('articles', [])
    context['feed_status'] = session_data.get('feed_status', [])
    context['gnews_status'] = session_data.get('gnews_status', [])
    context['total_collected'] = len(context['articles'])

    ok_feeds = [f for f in context['feed_status'] if f['status'] == 'ok']
    err_feeds = [f for f in context['feed_status'] if f['status'] == 'error']

    # Fontes com problema nesta passada (toast na interface + PDF)
    context['feed_errors'] = [
        {'name': f['name'], 'message': f.get('message', 'erro')}
        for f in (context['feed_status'] + context['gnews_status'])
        if f.get('status') not in ('ok', 'no_results')
    ]

    logger.info(f"[01] Coleta concluida: {context['total_collected']} artigos de {len(ok_feeds)} feeds")
    if err_feeds:
        logger.warning(f"[01] Feeds com erro: {[f['name'] for f in err_feeds]}")

    # ---------------------------------------------------------------
    # Coleta baixa = sempre tem causa identificavel (fonte bloqueando,
    # egress instavel, janela de 24h vazia, keywords descartando). O
    # detalhe por fonte no log responde "por que nao vieram noticias"
    # sem precisar abrir a bolha de status da interface.
    # ---------------------------------------------------------------
    all_status = context['feed_status'] + context['gnews_status']
    no_results = [f for f in all_status if f.get('status') == 'no_results']
    if context['feed_errors']:
        for f in context['feed_errors']:
            logger.warning(f"[01] fonte com erro: {f['name']} -> {f['message']}")
    if no_results:
        logger.info(f"[01] fontes sem itens novos na janela "
                    f"({context['session_data'].get('window_hours', '?')}h): "
                    f"{[f['name'] for f in no_results]}")
    if context['total_collected'] < 15:
        det = ', '.join(
            f"{f['name']}={f.get('articles', 0) if f.get('status') == 'ok' else f.get('status')}"
            for f in sorted(all_status, key=lambda s: s.get('name', '').lower()))
        logger.warning(f"[01] coleta baixa ({context['total_collected']} artigos) "
                       f"- detalhe por fonte: {det}")

    return context


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
    ctx = {}
    ctx = run(ctx)
    print(f"Coletados: {ctx['total_collected']} artigos")
