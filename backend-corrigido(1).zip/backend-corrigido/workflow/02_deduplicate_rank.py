# -*- coding: utf-8 -*-
"""
Workflow Etapa 02 - Desduplicacao e Ranqueamento
Remove duplicatas, ranqueia por relevancia e seleciona os melhores artigos.
"""
import sys
import os
import re
import logging

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

logger = logging.getLogger('workflow.02')

# Pesos para tipos de ameaca
THREAT_WEIGHTS = {
    'ransomware': 3, 'apt': 3, 'zero-day': 3, 'cve': 2, 'exploit': 2,
    'data breach': 3, 'supply chain': 3, 'nation-state': 3, 'state-sponsored': 3,
    'malware': 2, 'phishing': 1, 'ddos': 1, 'vulnerability': 1,
    'backdoor': 2, 'trojan': 2, 'stealer': 2, 'infostealer': 2,
    'wiper': 3, 'botnet': 2, 'credential': 2, 'intrusion': 2,
    'cyberattack': 2, 'extortion': 2, 'lateral movement': 2,
    'threat actor': 2, 'grupo apt': 3,
    'vazamento de dados': 3, 'ciberataque': 2, 'incidente de seguran': 2,
}

# Fontes com maior peso (mais confiaveis)
SOURCE_WEIGHTS = {
    'The Hacker News': 1.5, 'Krebs on Security': 1.8,
    'Securelist (Kaspersky)': 1.5, 'The DFIR Report': 1.6,
    'Security Affairs': 1.4, 'SANS Internet Storm Center': 1.4,
    'Unit 42 (Palo Alto Networks)': 1.5, 'Palo Alto Research': 1.4,
    'Google Project Zero': 1.5, 'Google Online Security Blog': 1.3,
    'Bleeping Computer': 1.3, 'BleepingComputer': 1.4,
    'SecurityWeek': 1.3, 'The Record (Recorded Future)': 1.4,
    'The Record': 1.4, 'CyberScoop': 1.3,
    'Google Cloud Threat Intelligence (Mandiant)': 1.4,
    'Volexity Blog': 1.3, 'Volexity': 1.3,
    'Cisco Talos Intelligence': 1.3, 'Check Point Research': 1.2,
    'Sentinel Labs (SentinelOne)': 1.2, 'Sophos News': 1.1,
    'Microsoft Security Blog': 1.3, 'CrowdStrike Blog': 1.3,
    'Dark Reading': 1.2, 'Malwarebytes Labs': 1.2,
    'ESET We Live Security': 1.2, 'Trend Micro Simply Security': 1.2,
    'Threat Intelligence Feed': 1.2,
    'Infosecurity Magazine - Threat Intel': 1.2,
    'Infosecurity Magazine - News': 1.1,
    'Cyber Security News': 1.1, 'The Cyber Express': 1.0,
    'Hackread': 1.1, 'CISO Advisor': 1.1,
    'Cyber Security Brazil': 1.2, 'Convergencia Digital': 1.0,
    'Olhar Digital - Seguranca': 0.9, 'Canaltech - Seguranca': 0.9,
    'Canaltech': 0.9, 'Tecnoblog - Seguranca': 0.9,
    'G1 - Tecnologia': 0.8,
    'Ars Technica Security': 1.0, 'WIRED Security': 1.0,
    'ZDNet Security': 1.0, 'Lenny Zeltser': 1.0,
    'The Hacker News (blogger)': 1.5,
    'The Hacker News (web)': 1.5,
    'CrowdStrike Blog (web)': 1.3, 'InfoSec Magazine Threat Intel': 1.2,
    'Dark Reading Threat Intel (web)': 1.2, 'OLH Digital Seguranca': 0.9,
}


def _compute_title_similarity(title1, title2):
    """Similaridade simples entre titulos (palavras em comum)."""
    words1 = set(re.findall(r'\b\w{4,}\b', title1.lower()))
    words2 = set(re.findall(r'\b\w{4,}\b', title2.lower()))
    if not words1 or not words2:
        return 0.0
    intersection = words1 & words2
    union = words1 | words2
    return len(intersection) / len(union) if union else 0.0


def _score_article(article):
    """Calcula pontuacao de relevancia de um artigo."""
    score = 0.0
    text = f"{article.get('title', '')} {article.get('summary', '')}".lower()

    for kw, weight in THREAT_WEIGHTS.items():
        if kw in text:
            score += weight

    source = article.get('source', '')
    score *= SOURCE_WEIGHTS.get(source, 1.0)

    if article.get('summary') and len(article['summary']) > 100:
        score += 0.5

    return round(score, 2)


def run(context):
    """Desdeduplica e ranqueia os artigos coletados."""
    logger.info("[02] Iniciando desduplicacao e ranqueamento...")
    articles = context.get('articles', [])
    original_count = len(articles)

    if not articles:
        logger.warning("[02] Nenhum artigo para processar.")
        context['articles'] = []
        context['removed_dupes'] = 0
        context['ranking'] = []
        return context

    # --- Ordena por data (mais recente primeiro) ANTES da dedup ---
    # assim, quando duas materias iguais chegam de fontes diferentes,
    # fica a versao mais nova do artigo.
    articles = sorted(articles,
                      key=lambda a: a.get('published', '') or '',
                      reverse=True)

    # --- Desduplicacao por similaridade de titulo ---
    keep_indices = []
    for i, art in enumerate(articles):
        is_dupe = False
        for j in keep_indices:
            sim = _compute_title_similarity(art['title'], articles[j]['title'])
            if sim >= 0.6:
                is_dupe = True
                logger.debug(f"[02] Duplicata removida: '{art['title'][:60]}' "
                             f"~ '{articles[j]['title'][:60]}'")
                break
        if not is_dupe:
            keep_indices.append(i)

    deduped = [articles[i] for i in keep_indices]
    removed = original_count - len(deduped)

    # --- Ranqueamento por relevancia ---
    ranked = []
    for art in deduped:
        art_copy = dict(art)
        art_copy['relevance_score'] = _score_article(art_copy)
        ranked.append(art_copy)

    # ORDEM FINAL: da notícia mais recente para a mais antiga
    # (score de ameaça fica como critério de desempate)
    ranked.sort(key=lambda x: (x.get('published', '') or '',
                               x.get('relevance_score', 0)),
                reverse=True)

    context['articles'] = ranked
    context['removed_dupes'] = removed
    # metrica de ranking (top 20 por score) usada apenas no log
    by_score = sorted(ranked, key=lambda x: x['relevance_score'], reverse=True)
    context['ranking'] = [{'title': a['title'][:60], 'score': a['relevance_score']}
                          for a in by_score[:20]]

    # sincroniza a sessao com os artigos (site + PDF exibem na ordem
    # mais recente -> mais antiga, com relevance_score no meta)
    if 'session_data' in context:
        context['session_data']['articles'] = ranked
        context['session_data']['total_articles'] = len(ranked)
        context['session_data']['removed_dupes'] = removed

    logger.info(f"[02] {original_count} -> {len(ranked)} artigos (removidas {removed} duplicatas)")
    if ranked:
        logger.info("[02] Ordem: mais recente -> mais antiga")
        logger.info(f"[02] Top 3 score: {[(a['title'][:40], a['relevance_score']) for a in by_score[:3]]}")

    return context


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
    ctx = {
        'articles': [
            {'title': 'New Ransomware Attack Targets Healthcare',
             'summary': 'A ransomware group...', 'source': 'The Hacker News'},
            {'title': 'Ransomware Attack Targets Healthcare Sector',
             'summary': 'Healthcare...', 'source': 'Krebs on Security'},
            {'title': 'Phishing Campaign Uses New Technique',
             'summary': 'A new phishing...', 'source': 'Krebs on Security'},
        ]
    }
    ctx = run(ctx)
    for a in ctx['articles']:
        print(f"  [{a['relevance_score']}] {a['title']}")
