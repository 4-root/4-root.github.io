# -*- coding: utf-8 -*-
"""
Workflow Orchestrator - 4root News
Coordena a execucao sequencial das etapas do workflow.
Cada etapa e um arquivo Python numerado na pasta workflow/.

Etapas (sem geracao por IA):
    01_collect          - Coleta paralela de feeds (RSS + Google News)
    02_deduplicate_rank - Desduplicacao e ordenacao (mais recente -> mais antiga)
    03_export           - Salvamento da sessao e PDF do ciclo
"""
import os
import sys
import json
import time
import threading
import logging
import importlib.util
from datetime import datetime, timezone

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from config import COLLECT_COOLDOWN_SECONDS, now_local
from maintenance import cleanup_old_artifacts

WORKFLOW_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
LOGS_DIR = os.path.join(BASE_DIR, 'logs')

os.makedirs(LOGS_DIR, exist_ok=True)

logger = logging.getLogger('workflow')

# ---------------------------------------------------------------
# Cooldown global da coleta: qualquer disparo (manual, botao ou
# scheduler) atualiza o timestamp; novos disparos so sao aceitos
# depois de COLLECT_COOLDOWN_SECONDS (padrao: 3600s / 1 hora)
# contados a partir da ULTIMA coleta de qualquer origem.
# ---------------------------------------------------------------
_last_run = {'ts': 0.0}
_rl_lock = threading.Lock()


def seconds_since_last_run():
    """Segundos desde o ultimo ciclo iniciado (qualquer origem)."""
    with _rl_lock:
        if not _last_run['ts']:
            return None
        return max(0.0, time.time() - _last_run['ts'])


def last_run_iso():
    """ISO local do inicio da ultima coleta ('' se nunca rodou)."""
    with _rl_lock:
        if not _last_run['ts']:
            return ''
        return datetime.fromtimestamp(_last_run['ts']).isoformat()


def cooldown_retry_after():
    """Segundos restantes do cooldown (0 se liberado)."""
    elapsed = seconds_since_last_run()
    if elapsed is None:
        return 0
    return max(0, int(round(COLLECT_COOLDOWN_SECONDS - elapsed)))


# alias de compatibilidade (usado por rotas antigas)
rate_limit_retry_after = cooldown_retry_after


STEPS = [
    {'id': '01', 'name': 'Coleta de Feeds (paralela)', 'module': '01_collect', 'function': 'run'},
    {'id': '02', 'name': 'Desduplicacao e Ranqueamento', 'module': '02_deduplicate_rank', 'function': 'run'},
    {'id': '03', 'name': 'Salvamento e Exportacao PDF', 'module': '03_export', 'function': 'run'},
]


def _load_step(step_def):
    """Carrega dinamicamente o modulo de uma etapa."""
    module_name = step_def['module']
    module_path = os.path.join(WORKFLOW_DIR, f'{module_name}.py')

    if not os.path.exists(module_path):
        raise FileNotFoundError(f"Arquivo do workflow nao encontrado: {module_path}")

    spec = importlib.util.spec_from_file_location(module_name, module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    return getattr(module, step_def['function'])


def run_full_pipeline():
    """Executa o pipeline completo de workflow (coleta -> dedup/rank -> PDF)."""
    with _rl_lock:
        _last_run['ts'] = time.time()      # marca inicio (cooldown 1h)

    context = {
        'workflow_id': now_local().strftime('%Y%m%d_%H%M%S'),
        'started_at': datetime.now(timezone.utc).isoformat(),
        'step_results': [],
        'errors': [],
    }

    sep = '=' * 60
    logger.info(sep)
    logger.info(f'WORKFLOW INICIADO - {len(STEPS)} etapas')
    logger.info(sep)

    for step_def in STEPS:
        step_num = step_def['id']
        step_name = step_def['name']
        step_start = time.time()

        logger.info('')
        logger.info(f'>> ETAPA {step_num}: {step_name}')
        logger.info('-' * 50)

        try:
            step_func = _load_step(step_def)
            context = step_func(context)

            elapsed = time.time() - step_start
            status = 'SUCCESS'
            logger.info(f'<< ETAPA {step_num} concluida em {elapsed:.1f}s - {status}')

        except Exception as exc:  # noqa: BLE001
            elapsed = time.time() - step_start
            status = 'ERROR'
            error_msg = f"{step_name}: {exc}"
            logger.error(f'<< ETAPA {step_num} FALHOU em {elapsed:.1f}s - {error_msg}')
            context['errors'].append({'step': step_num, 'name': step_name,
                                      'error': error_msg})

        context['step_results'].append({
            'step': step_num,
            'name': step_name,
            'status': status,
            'elapsed_seconds': round(elapsed, 1),
        })

        if status == 'ERROR':
            logger.error(f"Workflow interrompido na etapa {step_num}.")
            break

    context['finished_at'] = datetime.now(timezone.utc).isoformat()
    context['success'] = len(context['errors']) == 0
    context['export_path'] = context.get('export_path')

    logger.info('')
    logger.info(sep)
    logger.info('WORKFLOW FINALIZADO')
    logger.info(f"Status: {'SUCESSO' if context['success'] else 'COM ERROS'}")
    logger.info(f"Artigos coletados: {context.get('total_collected', 0)} | "
                f"apos dedup/ranqueamento (no PDF): "
                f"{len(context.get('articles', []))}")
    logger.info(f"Export: {context.get('export_path', 'N/A')}")
    if context['errors']:
        logger.error(f"Erros: {context['errors']}")
    logger.info(sep)

    _save_workflow_log(context)

    # Retencao: mantem apenas RETENTION_DAYS dias de sessoes/PDFs/logs
    try:
        cleanup_old_artifacts()
    except Exception as exc:  # noqa: BLE001
        logger.warning(f"[retencao] falhou ao limpar arquivos antigos: {exc}")

    return context


def _save_workflow_log(context):
    """Salva o log da execucao do workflow (auditoria; retencao limpa os antigos)."""
    log_path = os.path.join(DATA_DIR, f"workflow_{context['workflow_id']}.json")
    with open(log_path, 'w', encoding='utf-8') as f:
        json.dump(context, f, ensure_ascii=False, indent=2, default=str)


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(os.path.join(LOGS_DIR, 'workflow.log'), encoding='utf-8')
        ]
    )
    result = run_full_pipeline()
    print(json.dumps({
        'success': result['success'],
        'articles': result.get('total_collected', 0),
        'export': result.get('export_path'),
        'errors': result['errors']
    }, indent=2, ensure_ascii=False))
