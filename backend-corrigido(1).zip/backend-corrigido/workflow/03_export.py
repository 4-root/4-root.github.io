# -*- coding: utf-8 -*-
"""
Workflow Etapa 03 - Salvamento e Exportacao
Salva a sessao com os artigos ranqueados (da mais recente para a mais
antiga) e SEMPRE gera o PDF do ciclo (digest das noticias - sem geracao
por IA). O PDF fica disponivel para download pelo botao de export e
pelos session-chips da interface.
"""
import sys
import os
import logging

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import BRIEFING_ORG
from feeds_collector import save_session
from briefing_generator import generate_news_digest_pdf, format_date_ddmmaaaa

logger = logging.getLogger('workflow.03')


def run(context):
    """Salva a sessao e exporta o PDF do ciclo (digest das noticias)."""
    session_data = context.get('session_data', {})

    logger.info(f"[03] Salvando sessao ({session_data.get('total_articles', 0)} artigos)...")

    export_path = None
    session_id = session_data.get('session_id', 'latest')

    if session_data.get('articles'):
        date_str = format_date_ddmmaaaa()
        digest_name = f"BRIEFING - {BRIEFING_ORG} - {date_str} - {session_id}.pdf"
        export_path = generate_news_digest_pdf(session_data, digest_name)
        if export_path:
            session_data['pdf_file'] = os.path.basename(export_path)
            session_data['pdf_name'] = digest_name
            logger.info(f"[03] PDF do ciclo gerado: {digest_name} "
                        f"({len(session_data['articles'])} artigos ranqueados)")
        else:
            logger.warning("[03] Nao foi possivel gerar o PDF do ciclo.")
    else:
        logger.info("[03] Nenhum artigo coletado - PDF nao gerado.")

    save_session(session_data)
    context['session_data'] = session_data
    context['export_path'] = export_path

    logger.info(f"[03] Sessao salva ({session_id})")
    return context


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
    print("Etapa 03: depende do contexto das etapas anteriores.")
