# -*- coding: utf-8 -*-
"""
4root News - pacote do workflow numerado.

Etapas (sem geracao por IA):
    01_collect          - Coleta paralela de feeds RSS e GNews
    02_deduplicate_rank - Desduplicacao e ordenacao (mais recente -> mais antiga)
    03_export           - Salvamento da sessao e geracao do PDF do ciclo
"""
