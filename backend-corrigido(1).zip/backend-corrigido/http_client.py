# -*- coding: utf-8 -*-
"""
Camada HTTP endurecida do 4root News (usada por feeds_collector e
gnews_resolver).

POR QUE ESTE MODULO EXISTE
--------------------------
Entre 23/out e 07/nov/2026 a coleta no Replit passou a falhar com
SSLEOFError / SSL: UNEXPECTED_EOF_WHILE_READING em ~1/3 das fontes
(todas as hospedadas no Google - feeds.feedburner.com, *.blogspot.com,
security.googleblog.com, news.google.com - e varias outras atraves de
CDN). Diagnostico feito em 07/nov/2026: os MESMOS feeds respondem
HTTP 200 de uma rede neutra com a mesma stack, ou seja, o problema nao
e o codigo nem os sites - e o CAMINHO de saida do Replit (IP egress
compartilhado com reputacao ruim / middlebox cortando TLS no meio do
handshake).

Defesas implementadas (em ordem):
  1. TLS limitado a 1.2 - evita patologias de TLS 1.3 em middleboxes
     (fonte conhecida de SSLEOFError com urllib3 2.x);
  2. N retries (HTTP_RETRIES, padrao 3) com backoff exponencial +
     jitter e CONEXAO NOVA a cada tentativa (socket envenenado nao
     recontamina a retry);
  3. apos esgotar as retries, ultima cartada via curl_cffi
     impersonando Chrome 124 - stack TLS de browser, que atravessa
     middleboxes que derrubam a stack TLS do Python. Opcional (se o
     pacote nao estiver instalado, apenas pula);
  4. timeout separado connect/read - host morto falha rapido (10s no
     handshake), feed lento ganha tempo de leitura (FETCH_TIMEOUT);
  5. trust_env=False - nao herda proxy do ambiente do host (evita que
     um proxy injetado/quebrado no Replit degrade a coleta). Proxy
     explicito pode ser definido via env PROXY_URL (escape hatch caso
     o egress do host esteja queimado - a coleta inteira sai por ele).

As respostas retornadas tem a interface minima usada pelo resto do
codigo (.status_code, .content, .text, .raise_for_status()), seja da
stack requests seja da fallback curl_cffi.
"""
import logging
import random
import ssl
import threading
import time

import requests
from requests.adapters import HTTPAdapter

from config import FETCH_TIMEOUT, HTTP_RETRIES, PROXY_URL

logger = logging.getLogger(__name__)

USER_AGENT = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36')

HTTP_HEADERS = {
    'User-Agent': USER_AGENT,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
}

CONNECT_TIMEOUT = 10   # limite so para handshake/TCP (host morto falha rapido)
_BACKOFF_BASE = 2.0    # backoff exponencial: ~2s, ~4s, ~8s (+ jitter)

# ----------------------------------------------------------------
# Estado global protegido
# ----------------------------------------------------------------
_thread_local = threading.local()
_curl_checked = False
_curl_available = False
_curl_lock = threading.Lock()


class _TLS12Adapter(HTTPAdapter):
    """Pool HTTP com TLS limitado a 1.2.

    Alguns middleboxes/proxies de saida engasgam com features de TLS 1.3
    (session tickets, post-handshake, key_update) e cortam a conexao no
    meio do handshake - exatamente o SSLEOFError visto no Replit. Todos
    os feeds monitorados suportam TLS 1.2, entao limitar a versao nao
    perde nada e elimina essa classe de falha.
    """

    def init_poolmanager(self, *args, **kwargs):
        try:
            from urllib3.util.ssl_ import create_urllib3_context
            ctx = create_urllib3_context()
            ctx.maximum_version = ssl.TLSVersion.TLSv1_2   # urllib3 2.x
            kwargs['ssl_context'] = ctx
        except Exception:  # noqa: BLE001 - urllib3 1.x: caminho antigo
            kwargs.setdefault('ssl_version', ssl.PROTOCOL_TLSv1_2)
        super().init_poolmanager(*args, **kwargs)


def _new_session():
    """Cria uma Session limpa (headers + TLS 1.2 + proxy opcional)."""
    sess = requests.Session()
    sess.headers.update(HTTP_HEADERS)
    # Nao herdar proxy/CA do ambiente do host: no Replit um proxy
    # injetado (ou ausente) pode degradar a coleta. Proxy explicito
    # e opt-in via PROXY_URL.
    sess.trust_env = False
    if PROXY_URL:
        sess.proxies.update({'http': PROXY_URL, 'https': PROXY_URL})
    try:
        sess.mount('https://', _TLS12Adapter(max_retries=0))
    except Exception:  # noqa: BLE001 - nunca quebrar por causa do mount
        pass
    return sess


def _http():
    """Session da thread atual (reaproveita keep-alive na 1a tentativa)."""
    sess = getattr(_thread_local, 'session', None)
    if sess is None:
        sess = _new_session()
        _thread_local.session = sess
    return sess


def _curl_support():
    """True se o curl_cffi esta importavel (checa uma vez)."""
    global _curl_checked, _curl_available
    with _curl_lock:
        if not _curl_checked:
            _curl_checked = True
            try:
                import curl_cffi  # noqa: F401
                _curl_available = True
            except ImportError:
                _curl_available = False
                logger.info('[http] curl_cffi nao instalado - '
                            'fallback de browser desativado')
        return _curl_available


def _curl_request(method, url, *, headers=None, data=None, timeout=None):
    """Requisicao via curl_cffi impersonando Chrome 124.

    Usada apenas como ULTIMA tentativa: a stack TLS do browser (BoringSSL
    + fingerprint ja3 de Chrome) passa por middleboxes que cortam a stack
    TLS do Python. Retorna response com .status_code/.content/.text.
    """
    from curl_cffi import requests as creq

    hdrs = dict(headers or {})
    # a impersonacao ja envia UA/headers de Chrome coerentes; sobra so
    # o que importa (Accept, Accept-Language, Content-Type...)
    hdrs.pop('User-Agent', None)

    kwargs = {'timeout': float(timeout or FETCH_TIMEOUT),
              'impersonate': 'chrome124',
              'allow_redirects': True}
    if hdrs:
        kwargs['headers'] = hdrs
    if data is not None:
        kwargs['data'] = data
    if PROXY_URL:
        # 'proxies' e aceito de forma estavel entre versoes do curl_cffi
        # (o 'proxy' singular so existe a partir do 0.7)
        kwargs['proxies'] = {'http': PROXY_URL, 'https': PROXY_URL}

    return creq.request(method, url, **kwargs)


def http_request(url, method='GET', *, data=None, headers=None,
                 attempts=None, timeout=None):
    """GET/POST endurecido - ponto de entrada unico da coleta.

    - tenta na session da thread (keep-alive); nas retries, SEMPRE cria
      session nova (a conexao antiga pode ser a propria causa da falha);
    - backoff exponencial com jitter entre tentativas;
    - erros 4xx/5xx NAO sao reintentados (semantica mantida do projeto);
    - esgotou retries em excecao de rede -> 1 tentativa final via
      curl_cffi (Chrome). Se tambem falhar, re-levanta a ultima excecao.

    Retorna response (requests ou curl_cffi - duck-type compativel).
    """
    attempts = max(1, attempts or HTTP_RETRIES)
    if timeout is None:
        timeout = (CONNECT_TIMEOUT, FETCH_TIMEOUT)

    last_exc = None
    for attempt in range(attempts):
        sess = _http() if attempt == 0 else _new_session()
        try:
            kwargs = {'timeout': timeout, 'allow_redirects': True}
            if headers:
                kwargs['headers'] = headers
            if data is not None:
                kwargs['data'] = data
            return sess.request(method, url, **kwargs)
        except requests.exceptions.RequestException as exc:
            last_exc = exc
            if attempt + 1 < attempts:
                pause = _BACKOFF_BASE * (2 ** attempt) + random.uniform(0, 1)
                logger.debug(f'[http] retry {attempt + 2}/{attempts} em '
                             f'{pause:.1f}s - {type(exc).__name__}: '
                             f'{str(exc)[:80]}')
                time.sleep(pause)

    if last_exc is not None and _curl_support():
        try:
            resp = _curl_request(method, url, headers=headers, data=data,
                                 timeout=timeout[1] if isinstance(timeout, tuple)
                                 else timeout)
            logger.info(f'[http] fallback curl_cffi (Chrome) usada para '
                        f'{urlparse_host(url)} apos {attempts} falhas TLS')
            return resp
        except Exception as exc2:  # noqa: BLE001
            logger.debug(f'[http] fallback curl_cffi tambem falhou: '
                         f'{type(exc2).__name__}: {str(exc2)[:80]}')

    raise last_exc  # type: ignore[misc]


def urlparse_host(url):
    """Host curto para logs (sem dependencia extra)."""
    try:
        from urllib.parse import urlparse
        return urlparse(url).hostname or url
    except Exception:  # noqa: BLE001
        return url


def http_get(url, *, attempts=None, timeout=None):
    """Atalho GET (interface antiga _get_with_retry)."""
    return http_request(url, 'GET', attempts=attempts, timeout=timeout)
