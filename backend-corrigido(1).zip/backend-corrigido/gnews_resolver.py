# -*- coding: utf-8 -*-
"""
Resolvedor de links do Google News -> URL final da fonte.

O RSS do Google News retorna links intermediarios:
  https://news.google.com/rss/articles/CBMi...?oc=5

Dois formatos existem na natureza:
  1. ANTIGO (ate mid-2024): o base64 embute a URL final (protobuf).
     Resolve LOCAL, sem rede.
  2. NOVO (AU_yqL...): exige a assinatura/timestamp da pagina do artigo
     + uma chamada ao RPC interno "batchexecute" (Fbv4je/garturlreq).

V2 - correcao do bug de links permutados
----------------------------------------
FATOS apurados em testes reais (out/2026) que derrubam o modo lote:

  1. A resposta do batchexecute NAO ecoa o gn_art_id: cada item traz
     apenas ["garturlres", "<url>", 1];
  2. A resposta NAO preserva a ordem dos pedidos: num lote de 12 com
     12 respostas, 7 vieram em posicoes trocadas.

A V1 casava pedido<->resposta por POSICAO (zip) -> cada artigo recebia
a URL de OUTRO artigo (permutacao em cadeia) e o _cache guardava os
pares errados, envenenando os ciclos seguintes. Era a causa dos links
errados no site (titulo de uma materia, link de outra).

A V2 elimina o problema pela raiz: NAO existe mais lote. Cada artigo e
resolvido com 1 POST proprio (resposta unica = alinhamento garantido
por construcao), com POSTs paralelos (ThreadPoolExecutor) para manter
o ciclo rapido, e 1 retry em falha transitoria. Somente mapeamentos
validos (http e nao-gnews) sao aplicados e cacheados.

A coleta (feeds_collector.collect_all) chama resolve_links() ao final e
substitui cada link gnews pelo link original do publisher, para que o
site e o PDF apontem SEMPRE para a fonte final (nunca para o google news).

V3 - transporte endurecido (07/nov/2026)
---------------------------------------
As chamadas a news.google.com (GET de params + POST batchexecute)
passam a usar http_client.http_request: TLS 1.2, retries com backoff,
conexao nova por tentativa e fallback curl_cffi (Chrome). Com o egress
do Replit derrubando TLS, o resolver era o que mais sofria - sao dezenas
de chamadas seguidas ao Google por ciclo. O POST batchexecute e
idempotente na pratica (mesmo payload -> mesma resposta), entao retries
sao seguras aqui.

V4 - cache persistente (07/nov/2026)
------------------------------------
Os mapeamentos agora vivem em data/gnews_cache.json: um link resolvido
UMA vez fica resolvido para sempre, mesmo apos redeploy/restart do
Replit (que zerava o cache em memoria e fazia o mesmo artigo voltar a
apontar para o Google News ate ser resolvido de novo).

Uso isolado (teste manual):
    python3 gnews_resolver.py "https://news.google.com/rss/articles/CBMi...?oc=5"
"""
import base64
import json
import logging
import os
import re
import threading
import time
from urllib.parse import quote, urlparse

from bs4 import BeautifulSoup

from config import DATA_DIR, FETCH_TIMEOUT
from http_client import http_request

logger = logging.getLogger(__name__)

BATCHEXECUTE_URL = 'https://news.google.com/_/DotsSplashUi/data/batchexecute'
GNEWS_HOSTS = ('news.google.com', 'www.news.google.com')

# cache em memoria: link gnews -> url final (sobrevive entre ciclos no processo)
_cache = {}
_cache_lock = threading.Lock()
_cache_disk_loaded = False

# V4 - cache PERSISTENTE em disco (data/gnews_cache.json).
# No Replit cada redeploy/restart mata o processo e o cache em memoria
# morria junto - links ja resolvidos voltavam a ser gnews. Com o cache
# em disco, um link resolvido UMA vez fica resolvido para sempre (a
# janela de 24h faz o mesmo artigo repetir por ate 8 ciclos; resolveu
# no 1o, os seguintes custam zero rede).
CACHE_FILE = os.path.join(DATA_DIR, 'gnews_cache.json')
_CACHE_MAX = 5000          # entradas no disco (prune simples FIFO)


def _load_cache_disk():
    """Carrega o cache persistente para memoria (uma vez por processo)."""
    global _cache_disk_loaded
    with _cache_lock:
        if _cache_disk_loaded:
            return
        _cache_disk_loaded = True
    try:
        if os.path.exists(CACHE_FILE):
            with open(CACHE_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if isinstance(data, dict):
                valid = {k: v for k, v in data.items()
                         if isinstance(k, str) and _valid_final(v)}
                with _cache_lock:
                    _cache.update(valid)
                logger.info(f"[gnews-resolver] cache persistente carregado: "
                            f"{len(valid)} mapeamentos")
    except Exception as exc:  # noqa: BLE001 - cache corrompido = recomecar
        logger.warning(f"[gnews-resolver] cache persistente ilegivel "
                       f"(ignorado): {exc}")


def _save_cache_disk():
    """Salva o cache em disco (atomico via tmp+replace, prune FIFO)."""
    with _cache_lock:
        snapshot = dict(_cache)
    if len(snapshot) > _CACHE_MAX:
        snapshot = dict(list(snapshot.items())[-_CACHE_MAX:])
    try:
        tmp = CACHE_FILE + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(snapshot, f, ensure_ascii=False)
        os.replace(tmp, CACHE_FILE)
    except Exception as exc:  # noqa: BLE001 - disco cheio/readonly: seguir
        logger.debug(f"[gnews-resolver] cache persistente nao salvo: {exc}")


def is_gnews_link(url):
    """True se o link ainda aponta para o Google News."""
    if not url:
        return False
    try:
        host = (urlparse(url).hostname or '').lower()
    except ValueError:
        return False
    if host not in GNEWS_HOSTS:
        return False
    return '/articles/' in (urlparse(url).path or '') or '/__i/rss/rd/articles/' in url


def _article_id(url):
    """Extrai o ID (segmento base64) de um link gnews."""
    m = re.search(r'/articles/([^?/]+)', url)
    return m.group(1) if m else None


def _valid_final(url):
    """URL final valida: http(s) e NAO e link do proprio Google News."""
    return bool(url) and url.startswith('http') and not is_gnews_link(url)


# ---------------------------------------------------------------
# Formato ANTIGO: URL embutida no base64 (protobuf 0x08 0x13 0x22)
# ---------------------------------------------------------------
def _decode_local(url):
    seg = _article_id(url)
    if not seg:
        return None
    pad = seg + '=' * (-len(seg) % 4)
    try:
        raw = base64.urlsafe_b64decode(pad).decode('latin-1')
    except Exception:  # noqa: BLE001
        return None
    # estrutura: prefixo (3 bytes) | len bytes | URL | (opcional) amp | sufixo
    if raw.startswith('\x08\x13\x22'):
        raw = raw[3:]
    if raw.endswith('\xd2\x01\x00'):
        raw = raw[:-3]
    if not raw:
        return None
    try:
        ln = ord(raw[0])
        if ln >= 0x80:  # varint de 2 bytes
            ln = (ln & 0x7F) | (ord(raw[1]) << 7)
            body = raw[2:2 + ln]
        else:
            body = raw[1:1 + ln]
    except (IndexError, TypeError):
        return None
    if body.startswith('http') and ' ' not in body:
        return body
    m = re.search(r'https?://[^\x00-\x1f\x7f-\xff"\\]+', raw)
    return m.group(0) if m else None


# ---------------------------------------------------------------
# Formato NOVO (AU_yqL): params da pagina + batchexecute (1 POST por artigo)
# ---------------------------------------------------------------
def _get_decoding_params(art_id):
    """Busca signature (data-n-a-sg) e timestamp (data-n-a-ts) da pagina."""
    r = http_request(f'https://news.google.com/rss/articles/{art_id}')
    r.raise_for_status()
    soup = BeautifulSoup(r.text, 'lxml')
    div = soup.select_one('c-wiz > div')
    sig = div.get('data-n-a-sg') if div else None
    ts = div.get('data-n-a-ts') if div else None
    if not sig or not ts:
        raise ValueError('params de decodificacao ausentes')
    return {'gn_art_id': art_id, 'signature': sig, 'timestamp': ts}


def _collect_wrb(node, out):
    """Varre a resposta (qualquer forma de envelope) e coleta, em ordem,
    todos os itens cujo primeiro elemento e 'wrb.fr'."""
    if not isinstance(node, list):
        return
    if node and node[0] == 'wrb.fr':
        out.append(node)
        return
    for child in node:
        _collect_wrb(child, out)


def _batch_decode(params_list):
    """POST ao batchexecute. Retorna a lista de URLs brutas na ordem em
    que o Google as devolveu.

    ATENCAO: a resposta NAO ecoa o gn_art_id e NAO preserva a ordem dos
    pedidos - por isso esta funcao SO e usada com params_list de tamanho
    1 (via _batch_decode_single), onde alinhamento nao e um problema.
    Mantida para o fluxo single e para depuracao manual.
    """
    reqs = [[
        'Fbv4je',
        (f'["garturlreq",[["X","X",["X","X"],null,null,1,1,"US:en",null,1,null,null,'
         f'null,null,null,0,1],"X","X",1,[1,1,1],1,1,null,0,0,null,0],'
         f'"{p["gn_art_id"]}",{p["timestamp"]},"{p["signature"]}"]'),
    ] for p in params_list]
    payload = f'f.req={quote(json.dumps([reqs]))}'
    r = http_request(
        BATCHEXECUTE_URL, method='POST', data=payload,
        headers={'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
                 'Referer': 'https://news.google.com/'},
        attempts=2, timeout=FETCH_TIMEOUT)
    r.raise_for_status()

    body = r.text.split('\n\n', 1)
    body = body[1] if len(body) > 1 else r.text
    try:
        data = json.loads(body)
    except ValueError:
        return []

    wrb_items = []
    _collect_wrb(data, wrb_items)

    out = []
    for res in wrb_items:
        url = None
        try:
            inner = json.loads(res[2])
            if isinstance(inner, list) and len(inner) > 1:
                url = inner[1]
        except (TypeError, ValueError, IndexError):
            url = None
        out.append(url if isinstance(url, str) else None)
    return out


def _batch_decode_single(params):
    """Um POST para UM artigo.

    Como o lote do Google nao ecoa id e nao preserva ordem, o unico
    casamento infalivel e 1 pedido -> 1 resposta. Retorna a URL final
    ou None (falha de decodificacao).
    """
    out = _batch_decode([params])
    if len(out) == 1:
        return out[0]
    return None


def _resolve_individual(params_list, workers=6, retries=1):
    """Resolve params em paralelo, 1 POST por artigo, com retry opcional
    para falhas transitorias (ex. 429).

    Retorna dict {gn_art_id: url_final} contendo SOMENTE urls validas.
    """
    import concurrent.futures as cf
    out = {}
    if not params_list:
        return out

    def _one(p):
        for tentativa in range(retries + 1):
            try:
                url = _batch_decode_single(p)
            except Exception as exc:  # noqa: BLE001
                logger.debug(f"[gnews-resolver] single falhou: {str(exc)[:60]}")
                url = None
            if _valid_final(url):
                return p['gn_art_id'], url
            if tentativa < retries:
                time.sleep(1.5)
        return p['gn_art_id'], None

    with cf.ThreadPoolExecutor(max_workers=workers) as pool:
        for art_id, url in pool.map(_one, params_list):
            if url:
                out[art_id] = url
    return out


def resolve_links(urls, workers=8, batch_size=40):
    """Resolve um conjunto de links gnews com alinhamento garantido.

    Retorna dict {link_original: link_final}. Links que nao forem gnews
    (ou que falharem) simplesmente nao aparecem no retorno - o chamador
    mantem o original nesses casos.

    Passos:
      1. filtra gnews e deduplica por gn_art_id (mesmo id com sufixos
         de query diferentes so entra uma vez);
      2. tentativa local (formato antigo, sem rede) por id;
      3. formato novo: params em paralelo (1 GET por id) + 1 POST por
         artigo em paralelo (_resolve_individual) - sem lote, sem
         casamento posicional;
      4. so cacheia mapeamentos validos (memoria + disco).

    Parametros `workers` e `batch_size` sao mantidos na assinatura por
    compatibilidade (batch_size nao e mais usado).
    """
    t0 = time.time()
    _load_cache_disk()          # cache persistente (1a chamada do processo)
    results = {}          # url original -> url final
    by_id = {}            # gn_art_id -> [urls originais]
    order = []            # ids na ordem de chegada (estabilidade)
    cached_hits = 0

    for u in urls:
        if not u or not is_gnews_link(u):
            continue
        with _cache_lock:
            cached = _cache.get(u)
        if cached and _valid_final(cached):
            results[u] = cached
            cached_hits += 1
            continue
        art_id = _article_id(u)
        if not art_id:
            continue
        if art_id not in by_id:
            by_id[art_id] = []
            order.append(art_id)
        by_id[art_id].append(u)

    pending_total = sum(len(v) for v in by_id.values())
    if not order:
        return results

    # 1) tentativa local (formato antigo - sem rede) por id
    needs_remote = []
    for art_id in order:
        local = None
        try:
            # o mesmo id compartilha o mesmo segmento base64:
            # decodifica uma vez usando uma URL representativa
            local = _decode_local(by_id[art_id][0])
        except Exception:  # noqa: BLE001
            local = None
        if local and _valid_final(local):
            for u in by_id[art_id]:
                results[u] = local
        else:
            needs_remote.append(art_id)

    local_ok = sum(len(by_id[a]) for a in order if a not in needs_remote)
    logger.info(f"[gnews-resolver] {pending_total} links ({len(order)} ids): "
                f"{cached_hits} em cache, {local_ok} locais, "
                f"{len(needs_remote)} via batchexecute (1 POST por artigo)")

    # 2) formato novo: params em paralelo + POSTs individuais em paralelo
    if needs_remote:
        import concurrent.futures as cf

        def _params(art_id):
            try:
                return _get_decoding_params(art_id)
            except Exception as exc:  # noqa: BLE001
                logger.debug(f"[gnews-resolver] params falhou: {str(exc)[:60]}")
                return None

        params_map = {}
        with cf.ThreadPoolExecutor(max_workers=workers) as pool:
            for art_id, p in zip(needs_remote,
                                 pool.map(_params, needs_remote)):
                if p:
                    params_map[art_id] = p

        params_list = [params_map[a] for a in needs_remote
                       if a in params_map]
        sem_params = len(needs_remote) - len(params_list)
        if sem_params:
            logger.warning(f"[gnews-resolver] {sem_params} ids sem params "
                           f"(ficam com o link gnews)")

        solved = _resolve_individual(params_list)

        # aplica e cacheia SOMENTE mapeamentos validos
        with _cache_lock:
            for art_id, final in solved.items():
                if not _valid_final(final):
                    continue
                for u in by_id.get(art_id, []):
                    results[u] = final
                    _cache[u] = final

    resolved = sum(1 for u in results if results[u] != u)
    logger.info(f"[gnews-resolver] resolvidos: {resolved}/{pending_total} "
                f"links apontam agora para a fonte final "
                f"({time.time() - t0:.1f}s)")
    _save_cache_disk()   # persiste mapeamentos novos (sobrevive a redeploys)
    return results


if __name__ == '__main__':
    import sys
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s [%(levelname)s] %(message)s')
    if len(sys.argv) > 1:
        mapping = resolve_links(sys.argv[1:])
        for k, v in mapping.items():
            print(f'{k[:80]}\n  -> {v}')
    else:
        print('uso: python3 gnews_resolver.py <link1> [link2] ...')