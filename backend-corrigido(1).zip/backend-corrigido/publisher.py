# -*- coding: utf-8 -*-
"""
Publicador de dados publicos do 4root News
==========================================
Gera o dicionario publico consumido pela interface. E a FONTE UNICA de
dados do frontend, servido pela API (Flask no Replit ou servidor proprio):

    app.py -> rota /data/news.json -> build_public_json(mode)
      mode='flask'  -> API na mesma origem do site (Flask local/dev)
      mode='replit' -> API publica (PUBLIC_API_URL, ex.: Replit)
                       usada pelo frontend estatico no GitHub Pages

Alem dos dados do ciclo, o JSON carrega a coordenacao do frontend:
api_base (onde ficam /collect e /export), cooldown da coleta manual e
status do scheduler (ciclo de 3h).
"""
import logging
from datetime import datetime, timezone

from config import (NEWS_WINDOW_HOURS, MESES_PT, BRIEFING_ORG,
                    PUBLIC_API_URL, COLLECT_COOLDOWN_SECONDS,
                    TZ_BRASILIA, now_local)
from feeds_collector import load_session, list_sessions
from workflow.orchestrator import cooldown_retry_after, last_run_iso

logger = logging.getLogger('publisher')


def _fmt_session_when(iso_date):
    """Formata a data de coleta do ciclo como 21OUT 09:00 (session-chip),
    convertida para o fuso de Brasilia (o dado chega em ISO UTC)."""
    raw = (iso_date or '')[:16]
    try:
        s = iso_date.strip()
        if s.endswith('Z'):
            s = s[:-1] + '+00:00'
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)   # legado sem offset
        dt = dt.astimezone(TZ_BRASILIA)
        return f"{dt.day}{MESES_PT.get(dt.month, '')} {dt.strftime('%H:%M')}"
    except (ValueError, TypeError, AttributeError):
        return raw.replace('T', ' ')


def _fmt_date_ddmmaaaa(dt=None):
    """Formata data como DDMMMAAAA (ex: 21OUT2026) - label da secao."""
    if dt is None:
        dt = now_local()
    return f"{dt.day}{MESES_PT.get(dt.month, '???')}{dt.year}"


def _merge_feed_status(session):
    """Une o status de todas as fontes do ciclo (RSS + gnews), ordenado."""
    if not session:
        return []
    status = session.get('feed_status', []) + session.get('gnews_status', [])
    return sorted(status, key=lambda s: s.get('name', '').lower())


def _scheduler_info(mode):
    """Estado da coleta automatica (daemon-thread da API, ciclo de 3h)."""
    try:
        import scheduler
        st = scheduler.status()
        return {
            'mode': mode,
            'status': 'ativa' if st.get('enabled') else 'manual',
            'interval_hours': st.get('interval_hours'),
            'next_run': (st.get('next_run') or '')[:19],
            'last_run': (st.get('last_run') or '')[:19],
        }
    except Exception:  # noqa: BLE001
        return {'mode': mode, 'status': '-', 'interval_hours': None,
                'next_run': '', 'last_run': ''}


def build_public_json(mode='flask'):
    """Monta o dicionario publico consumido pela interface estatica.

    mode: 'flask'  -> API na mesma origem (api_base vazio, Flask local)
          'replit' -> API publica (api_base = PUBLIC_API_URL, frontend no Pages)
    """
    session = load_session()
    articles = (session or {}).get('articles', [])
    feed_status = _merge_feed_status(session)
    total = len(feed_status)
    ok = len([f for f in feed_status if f.get('status') == 'ok'])
    err = len([f for f in feed_status if f.get('status') not in ('ok', 'no_results')])

    sessions = []
    for s in list_sessions()[:8]:
        sessions.append({
            'id': s.get('id', ''),
            'date': s.get('date', ''),
            'when': _fmt_session_when(s.get('date')),
            'total': s.get('total', 0),
            'pdf_file': s.get('pdf', ''),
        })

    return {
        'mode': mode,
        'api_base': PUBLIC_API_URL if mode == 'replit' else '',
        'generated_at': now_local().isoformat(),
        'org': BRIEFING_ORG,
        'date_full': _fmt_date_ddmmaaaa(),
        'session_id': (session or {}).get('session_id', ''),
        'collected_at': (session or {}).get('collected_at', ''),
        'last_collect_at': last_run_iso()[:19],
        'total_articles': len(articles),
        'window_hours': (session or {}).get('window_hours', NEWS_WINDOW_HOURS),
        'pdf_file': (session or {}).get('pdf_file', ''),
        'pdf_name': (session or {}).get('pdf_name', ''),
        'articles': articles,
        'sessions': sessions,
        'feed_status': feed_status,
        'feed_total': total,
        'feed_ok': ok,
        'feed_err': err,
        'feed_summary': (f'{ok}/{total} fontes respondendo'
                         if total else 'aguardando primeiro ciclo'),
        'cooldown_seconds': COLLECT_COOLDOWN_SECONDS,
        'collect_ready_in_seconds': cooldown_retry_after(),
        'scheduler': _scheduler_info(mode),
    }


if __name__ == '__main__':
    import json
    import logging as _log
    _log.basicConfig(level=logging.INFO,
                     format='%(asctime)s [%(levelname)s] %(message)s')
    print(json.dumps(build_public_json(
        mode='replit' if PUBLIC_API_URL else 'flask'),
        ensure_ascii=False, indent=2)[:2000])
